import pygame
from ..sound import *


class Player:
    def __init__(self, color, game):
        """
        constructor
        """
        self.color = color
        self.money = 1500
        self.position = 1
        self.is_in_prison = False
        self.prison_counter = 0
        self.board = game.board
        self.screen = game.screen
        self.message = game.message
        self.players = game.players
        self.dice = game.dice
        self.info_table = game.info_table
        self.is_moving = False
        self.turn_counter = 0
        self.move(0)  # need to first draw
        self.bankrupt = False
        self.jail_free_card = False


    def player_action(self):
        raise Exception("player_action() not implemented")

    def move(self, step, take_cash=True):
        self.is_moving = True
        self.turn_counter += 1
        actual_field = self.board.get_field(self.position)
        actual_field.add_player(self)

        if step < 0:
            step = abs(step)
            for x in range(step):
                sound.MOVE_SOUND.play(0)
                actual_field = self.board.get_field(self.position)
                actual_field.remove_player(self)
                self.position -= 1
                if self.position < 1:
                    self.position += 40
                actual_field = self.board.get_field(self.position)
                actual_field.add_player(self)
                self.board.draw(self.screen)
                self.dice.draw(self.screen)
                pygame.display.update()
                pygame.time.delay(200)
        else:
            for x in range(step):
                sound.MOVE_SOUND.play(0)
                actual_field = self.board.get_field(self.position)
                actual_field.remove_player(self)
                self.position += 1
                if self.position > 40:
                    self.position -= 40
                    if take_cash:
                        self.money += 200
                        self.message.add_message(f"gracz o kolorze {self.color} przeszeł przez START (+ $200)")
                        self.message.show_message(self.screen)
                        self.info_table.draw()
                        pygame.display.update()
                actual_field = self.board.get_field(self.position)
                actual_field.add_player(self)
                self.board.draw(self.screen)
                self.dice.draw(self.screen)
                pygame.display.update()
                pygame.time.delay(200)


        action_message = actual_field.player_on_field_action(self)
        if action_message:
            self.message.add_message(action_message)

        self.is_moving = False

    def repossession(self, money_to_pay):

        field = None
        for f in self.board.fields:
            if hasattr(f, 'owner'):
                if f.owner == self:
                    if field is None:
                        field = f
                    else:
                        field_value, f_value = 0, 0
                        if field.name == 'red':
                            field_value = 100
                        if field.name == 'yellow':
                            field_value = 40
                        if field.name == 'green':
                            field_value = 20
                        if field.name == 'darkblue':
                            field_value = 20
                        if field.name == 'orange':
                            field_value = 100
                        if field.name == 'pink':
                            field_value = 40
                        if field.name == 'lightblue':
                            field_value = 20
                        if field.name == 'brown':
                            field_value = 20
                        if field.name == 'satellite':
                            field_value = 10
                        if field.name == 'powerstation':
                            field_value = 15

                        if f.name == 'red':
                            f_value = 100
                        if f.name == 'yellow':
                            f_value = 40
                        if f.name == 'green':
                            f_value = 20
                        if f.name == 'darkblue':
                            f_value = 20
                        if f.name == 'orange':
                            f_value = 100
                        if f.name == 'pink':
                            f_value = 40
                        if f.name == 'lightblue':
                            f_value = 20
                        if f.name == 'brown':
                            f_value = 20
                        if f.name == 'satellite':
                            f_value = 10
                        if f.name == 'powerstation':
                            f_value = 15

                        if f_value < field_value:
                            field = f

        while self.money < money_to_pay and field is not None:
            if hasattr(field, 'home_counter'):
                # sprzedawanie domku jak monopol i są
                color_fields = self.board.get_all_color_fields(field.name)
                no_homes = True
                end = False
                for f in color_fields:
                    if f.home_counter > 4 and not end:
                        f.home_counter -= 1
                        self.money += int(f.att[10]/2)
                        end = True
                        self.message.add_message(f"komornik sprzedaje hotel z pola {field.att[14]}")
                        self.message.show_message(self.screen)
                        self.info_table.draw()
                        pygame.display.update()
                        sound.BUY_SOUND.play(0)
                        pygame.time.delay(1000)
                    elif f.home_counter > 0 and not end:
                        f.home_counter -= 1
                        self.money += int(f.att[9]/2)
                        end = True
                        self.message.add_message(f"komornik sprzedaje domek z pola {field.att[14]}")
                        self.message.show_message(self.screen)
                        self.info_table.draw()
                        pygame.display.update()
                        sound.BUY_SOUND.play(0)
                        pygame.time.delay(1000)
                    if f.home_counter > 0:
                        no_homes = False
                if no_homes and not end:
                    field.mortgage = True
                    self.money += int(f.att[1] / 2)
                    self.message.add_message(f"komornik zastawia pole {field.att[14]}")
                    self.message.show_message(self.screen)
                    self.info_table.draw()
                    pygame.display.update()
                    sound.BUY_SOUND.play(0)
                    pygame.time.delay(1000)

            field = None
            for f in self.board.fields:
                if hasattr(f, 'owner'):
                    if f.owner == self and not f.mortgage:
                        if field is None:
                            field = f
                        else:
                            field_value, f_value = 0, 0
                            if field.name == 'red':
                                field_value = 100
                            if field.name == 'yellow':
                                field_value = 40
                            if field.name == 'green':
                                field_value = 20
                            if field.name == 'darkblue':
                                field_value = 20
                            if field.name == 'orange':
                                field_value = 100
                            if field.name == 'pink':
                                field_value = 40
                            if field.name == 'lightblue':
                                field_value = 20
                            if field.name == 'brown':
                                field_value = 20
                            if field.name == 'satellite':
                                field_value = 10
                            if field.name == 'powerstation':
                                field_value = 15

                            if f.name == 'red':
                                f_value = 100
                            if f.name == 'yellow':
                                f_value = 40
                            if f.name == 'green':
                                f_value = 20
                            if f.name == 'darkblue':
                                f_value = 20
                            if f.name == 'orange':
                                f_value = 100
                            if f.name == 'pink':
                                f_value = 40
                            if f.name == 'lightblue':
                                f_value = 20
                            if f.name == 'brown':
                                f_value = 20
                            if f.name == 'satellite':
                                f_value = 10
                            if f.name == 'powerstation':
                                f_value = 15

                            if f_value < field_value:
                                field = f
