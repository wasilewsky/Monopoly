from .player import Player


class MainPlayer(Player):
    def __init__(self, color, game):
        super().__init__(color, game)

    def player_action(self):
        """
        main player actions are handled elsewhere
        """
        pass

