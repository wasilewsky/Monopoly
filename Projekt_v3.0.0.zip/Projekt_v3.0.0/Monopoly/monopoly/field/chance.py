import pygame
from .field import Field
from ..sound import *
from ..settings import chance_cards
import random


class Chance(Field):
    """
    representation of the 'chance' field
    """
    def __init__(self, index, pos_x, pos_y, image):
        super().__init__(index, 'chance', pos_x, pos_y, image)

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        pass

    def player_on_field_action(self, player):
        chance_card = random.choice(chance_cards)
        # print(chance_card)
        # chance_card = chance_cards[6]
        card_number, card_description = chance_card
        # print(f"Player {player.color} drew card {card_number}: {card_description}")

        pygame.draw.rect(self.screen, 'WHITE', (530, 550, 286, 176), 0, 10, -10, -10, -10,
                         -10)  # tło karty
        pygame.draw.rect(self.screen, (0, 0, 0), (533, 553, 280, 170), 2, 10, -10, -10, -10,
                         -10)  # ramka
        text5 = pygame.font.Font.render(pygame.font.SysFont(None, 40), f"KARTA SZANSY", True, (0, 0, 0))
        self.screen.blit(text5, (567, 574))

        card_description = card_description.replace(',', '.')
        card_description = card_description.replace('!', '.')
        if '.' in card_description:
            card_description1, card_description2 = card_description.split('.', 1)
        else:
            card_description1 = card_description
            card_description2 = ""

        text5 = pygame.font.Font.render(pygame.font.SysFont(None, 22), card_description1, True, (0, 0, 0))
        text_rect = text5.get_rect(center=(530 + 286 // 2, 635))
        self.screen.blit(text5, text_rect)

        text5 = pygame.font.Font.render(pygame.font.SysFont(None, 22), card_description2, True, (0, 0, 0))
        text_rect = text5.get_rect(center=(530 + 286 // 2, 665))
        self.screen.blit(text5, text_rect)

        pygame.display.update()
        pygame.time.delay(2000)

        if card_number == 1:
            player.move(41 - player.position)
        elif card_number == 2:
            step = 12 - player.position
            if step < 0:
                step = 40 + step
            player.move(step)
        elif card_number == 3:
            # go to nearest of (6, 16, 26, 36)
            steps = []
            for x in (6, 16, 26, 36):
                step = x - player.position
                if step < 0:
                    step = 40 + step
                steps.append(step)

            player.move(min(steps))

        elif card_number == 4:
            step = 25 - player.position
            if step < 0:
                step = 40 + step
            player.move(step)

        elif card_number == 5:
            player.jail_free_card = True
        elif card_number == 6:
            step = 6 - player.position
            if step < 0:
                step = 40 + step
            player.move(step)

        elif card_number == 7:
            steps = []
            for x in (13, 29):
                step = x - player.position
                if step < 0:
                    step = 40 + step
                steps.append(step)

            player.move(min(steps))

        elif card_number == 8:
            if player.money < 150:
                player.repossession(150)
                if player.money < 150:
                    player.bankrupt = True
                    return f'gracz {player.color} bankrutuje'
                else:
                    sound.BUY_SOUND.play(0)
                    player.players[1].money += 50
                    player.players[2].money += 50
                    player.players[3].money += 50
                    player.players[0].money += 50
                    player.money -= 200
            else:
                sound.BUY_SOUND.play(0)
                player.players[1].money += 50
                player.players[2].money += 50
                player.players[3].money += 50
                player.players[0].money += 50
                player.money -= 200

        elif card_number == 9:
            player.move(-3)

        elif card_number == 10:
            sound.BUY_SOUND.play(0)
            player.money += 50

        elif card_number == 11:  # ZA KAZDY DOM $25 A ZA HOTEL $100
            field_houses = 0
            field_hotels = 0
            for field in player.board.fields:
                if hasattr(field, 'owner'):
                    if field.owner == player:
                        if hasattr(field, 'home_counter'):
                            field_houses += field.home_counter
                            if field.home_counter > 4:
                                hotels = field.home_counter - 4
                                field_houses -= hotels
                                field_hotels += hotels
            if player.money < field_houses * 25 + field_hotels * 100:
                player.repossession(field_houses * 25 + field_hotels * 100)
                if player.money < field_houses * 25 + field_hotels * 100:
                    player.bankrupt = True
                    return f'gracz {player.color} bankrutuje'
                else:
                    if field_hotels > 0 or field_houses > 0:
                        sound.BUY_SOUND.play(0)
                    player.money -= field_houses * 25 + field_hotels * 100
            else:
                if field_hotels > 0 or field_houses > 0:
                    sound.BUY_SOUND.play(0)
                player.money -= field_houses * 25 + field_hotels * 100
        elif card_number == 12:  # IDZ DO WIEZIENIA
            step = 31 - player.position
            if step < 0:
                step = 40 + step
            player.move(step, False)
        elif card_number == 13:
            step = 40 - player.position
            if step < 0:
                step = 40 + step
            player.move(step)

        elif card_number == 14:
            if player.money < 15:
                player.repossession(15)
                if player.money < 15:
                    player.bankrupt = True
                    return f'gracz {player.color} bankrutuje'
                else:
                    player.money -= 15
                    sound.BUY_SOUND.play(0)
            else:
                player.money -= 15
                sound.BUY_SOUND.play(0)

        elif card_number == 15:
            sound.BUY_SOUND.play(0)
            player.money += 150

        elif card_number == 16:
            steps = []
            for x in (6, 16, 26, 36):
                step = x - player.position
                if step < 0:
                    step = 40 + step
                steps.append(step)

            player.move(min(steps))

        pygame.time.delay(1000)
        # return f'gracz {player.color} dostaje $100'

    def _draw_player(self, player, screen):
        if self.index == 8:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

        if self.index == 23:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

        if self.index == 37:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 40, self.pos_y + 18, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 60, self.pos_y + 18, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 40, self.pos_y + 38, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 60, self.pos_y + 38, 15, 15))
