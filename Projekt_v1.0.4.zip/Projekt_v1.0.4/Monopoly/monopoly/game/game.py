from ..board import *
from ..player import *
from ..message import *


class Game:
    def __init__(self, screen, selected_color):
        self.board = Board()
        self.screen = screen
        self.selected_color = selected_color
        self.players = []
        self._make_players()
        self.current_player_index = 3  # to do zmiany by było losowanie kostką
        self.message = Message()
        self.switch_player()  # to do wywalenia - jedynie test wypisywania

    def draw(self):
        self.board.draw(self.screen)
        self.message.show_message(self.screen)

    def _make_players(self):
        main_player = MainPlayer(self.selected_color)
        self.players.append(main_player)

        colors = ['red', 'blue', 'green', 'purple']
        colors.remove(self.selected_color)

        for color in colors:
            ai_player = AiPlayer(color)
            self.players.append(ai_player)

    def switch_player(self):
        self.current_player_index = (self.current_player_index + 1) % len(self.players)
        if self.current_player_index == 0:
            self.message.add_message('@ twoja kolej:')

