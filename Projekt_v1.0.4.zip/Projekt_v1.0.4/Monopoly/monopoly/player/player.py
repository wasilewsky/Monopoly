class Player:
    def __init__(self, color):
        """
        constructor
        """
        self.color = color
        self.money = 1500
        self.position = 1
        self.is_in_prison = False

    def player_action(self):
        raise Exception("player_action() not implemented")

