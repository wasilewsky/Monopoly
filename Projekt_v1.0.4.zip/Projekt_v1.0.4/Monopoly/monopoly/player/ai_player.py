from .player import Player


class AiPlayer(Player):
    def __init__(self, color):
        super().__init__(color)

    def player_action(self):
        pass
