from .field import Field
import pygame


class PowerStation(Field):
    """
    representation of the 'power station' field
    """
    def __init__(self, index, pos_x, pos_y, image, att, screen):
        super().__init__(index, 'powerstation', pos_x, pos_y, image)
        self.hitbox = pygame.Rect(self.pos_x, self.pos_y, self.image.get_width(), self.image.get_height())
        self.owner = None
        self.att = att
        self.screen = screen

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        # TODO napis

         if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            # ----------TŁO KARTY-----------------------
            pygame.draw.rect(self.screen, 'WHITE', (250, 550, 176, 286), 0, 10, -10, -10, -10,
                             -10)  # tło karty
            pygame.draw.rect(self.screen, (0, 0, 0), (253, 553, 170, 280), 2, 10, -10, -10, -10,
                             -10)  # ramka
            pygame.draw.rect(self.screen, (0, 0, 0), (256, 556, 164, 54), 2, 10, -10, -10, -10,
                             -10)  # ramka koloru
            text5 = pygame.font.Font.render(pygame.font.SysFont(None, 30), f"{self.att[14]}", True, (0, 0, 0))
            self.screen.blit(text5, (263, 574))
            # ------------------------------------------
            pos_x_left = 255
            pos_y = 617

            text11 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"        Przy posiadaniu", True,
                                             (0, 0, 0))
            self.screen.blit(text11, (pos_x_left, pos_y ))
            text12 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"   1 Zakładu, czynsz jest", True,
                                             (0, 0, 0))
            self.screen.blit(text12, (pos_x_left, pos_y + 20))
            text13 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"  czterokrotnością ilości",
                                             True,
                                             (0, 0, 0))
            self.screen.blit(text13, (pos_x_left, pos_y + 40))
            text14 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"     wyrzuconych oczek.",
                                             True,
                                             (0, 0, 0))
            self.screen.blit(text14, (pos_x_left, pos_y + 60))

            text11 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"        Przy posiadaniu", True,
                                             (0, 0, 0))
            self.screen.blit(text11, (pos_x_left, pos_y + 120))
            text12 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f" 2 Zakładów, czynsz jest", True,
                                             (0, 0, 0))
            self.screen.blit(text12, (pos_x_left, pos_y + 140))
            text13 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"    dziesięciokrotnością ",
                                             True,
                                             (0, 0, 0))
            self.screen.blit(text13, (pos_x_left, pos_y + 160))
            text14 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"ilości wyrzuconych oczek.",
                                             True,
                                             (0, 0, 0))
            self.screen.blit(text14, (pos_x_left, pos_y + 180))

    def player_on_field_action(self):
        # TODO opcja kupienia
        pass
