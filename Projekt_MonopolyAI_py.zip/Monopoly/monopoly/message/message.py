import pygame


class Message:
    def __init__(self):
        self.messages = []

    def show_message(self, screen):
        pygame.draw.rect(screen, 'WHITE', (1000, 232, 860, 500), 0, 10, -10, -10, -10, -10)
        pygame.draw.rect(screen, (0, 0, 0), (1000, 232, 860, 500), 2, 10, -10, -10, -10, -10)
        x = 262
        for m in self.messages:
            text = pygame.font.Font.render(pygame.font.SysFont(None, 40), f"{m}", True, (0, 0, 0))
            screen.blit(text, (1050, x))
            x += 45

    def add_message(self, message):
        if len(self.messages) >= 10:
            self.messages.pop(0)
        self.messages.append(message)
