import pygame


class InfoTable:
    def __init__(self, screen, players):
        self.pos_x = 1000
        self.pos_y = 100
        self.screen = screen
        self.players = players

    def draw(self):
        for i, player in enumerate(self.players):
            pos_x = self.pos_x + i * 217
            pos_y = self.pos_y

            colortable = (255, 255, 255)
            if hasattr(player, 'color'):
                if player.color == "red":
                    colortable = (255, 0, 0)
                elif player.color == "green":
                    colortable = (0, 255, 0)
                elif player.color == "blue":
                    colortable = (0, 100, 255)
                elif player.color == "purple":
                    colortable = (204, 0, 255)

            pygame.draw.rect(self.screen, (255, 255, 255), (pos_x, pos_y, 210, 117), 0)
            pygame.draw.rect(self.screen, colortable, (pos_x, pos_y, 210, 46), 0)
            pygame.draw.rect(self.screen, (0, 0, 0), (pos_x, pos_y, 210, 46), 2)
            pygame.draw.rect(self.screen, (0, 0, 0), (pos_x, pos_y, 210, 117), 2)

            text_name = pygame.font.Font.render(pygame.font.SysFont(None, 75), f"{player.color}", True, (0, 0, 0))
            self.screen.blit(text_name, (pos_x + 25, pos_y))

            if hasattr(player, 'money'):
                if player.bankrupt:
                    text_money = pygame.font.Font.render(pygame.font.SysFont(None, 65), "bankrut", True,
                                                         (0, 0, 0))
                else:
                    text_money = pygame.font.Font.render(pygame.font.SysFont(None, 65), f"${player.money}", True, (0, 0, 0))
                self.screen.blit(text_money, (pos_x + 20, pos_y + 60))
