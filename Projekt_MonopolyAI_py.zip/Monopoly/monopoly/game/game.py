from ..board import *
from ..player import *
from ..message import *
from ..button import *
from ..image import *
from ..info_table import *
from ..dice import *
from ..sound import *


class Game:
    def __init__(self, screen, selected_color):
        self.board = Board()
        self.screen = screen
        self.selected_color = selected_color
        self.message = Message()
        self.rzut_button = Button(1000, 750, image.RZUT_BTN, True)
        self.kup_button = Button(1220, 750, image.KUPPOLE_BTN, True)
        self.kupDom_button = Button(1440, 750, image.KUPDOM_BTN, True)
        self.sprzedajDom_button = Button(1660, 750, image.SPRZEDAJDOM_BTN, True)
        self.zastaw_button = Button(1000, 870, image.ZASTAW_BTN, True)
        self.wykup_button = Button(1220, 870, image.WYKUP_BTN, True)
        self.handel_button = Button(1440, 870, image.HANDEL_BTN, True)
        self.dalej_button = Button(1660, 870, image.DALEJ_BTN, True)
        self.handelnie = Button(280, 420, image.HANDELNIE, True)
        self.handeltak = Button(610, 420, image.HANDELTAK, True)
        self.minus10 = Button(280, 260, image.MINUS10, True)
        self.minus100 = Button(280, 320, image.MINUS100, True)
        self.plus10 = Button(680, 260, image.PLUS10, True)
        self.plus100 = Button(680, 320, image.PLUS100, True)
        self.trade_money = 0
        self.dice_rolled = False
        self.players = []
        self.info_table = InfoTable(screen, self.players)
        self.dice = Dice()
        self.round_counter = 0
        self.game_over = False
        self.end_message = '@ KONIEC GRY'
        self.trade_mode = False
        self._make_players()
        self.current_player_index = 3
        self.switch_player()


    def draw(self):
        parking = self.board.get_field(21)
        tax1 = self.board.get_field(5)
        tax2 = self.board.get_field(39)
        if parking.bank == -1:
            parking.bank = 0
            tax1.money_bank = 0
            tax2.money_bank = 0
        parking.bank = tax1.money_bank + tax2.money_bank

        self.board.draw(self.screen)
        if self.board.another_field:
            self.trade_mode = False
            self.board.another_field = False

        self.message.show_message(self.screen)
        self.info_table.draw()

        self.rzut_button.draw(self.screen)
        self.kup_button.draw(self.screen)
        self.kupDom_button.draw(self.screen)
        self.sprzedajDom_button.draw(self.screen)

        self.zastaw_button.draw(self.screen)
        self.wykup_button.draw(self.screen)
        self.handel_button.draw(self.screen)
        self.dalej_button.draw(self.screen)

        self.dice.draw(self.screen)

        if self.trade_mode:
            x, y = 270, 250
            pygame.draw.rect(screen, '#000000', (x-2, y-2, 504, 254))
            pygame.draw.rect(screen, '#ffffff', (x, y, 500, 250))
            self.handelnie.draw(self.screen)
            self.handeltak.draw(self.screen)
            self.minus10.draw(self.screen)
            self.minus100.draw(self.screen)
            self.plus10.draw(self.screen)
            self.plus100.draw(self.screen)
            font = pygame.font.SysFont(None, 30)
            text_surface_left = font.render(f"Kwota: {self.trade_money}", True,
                                            (0, 0, 0))
            self.screen.blit(text_surface_left, (x+200, y+50))
            self.handel_button.set_visible(False)
            self.handel_button.draw(self.screen)

        # -----------------wszystko rysujemy na początku pętli

        for p in self.players:
            if p.money < 0 and not p.bankrupt:
                p.bankrupt = True

        # game over
        if self.game_over:
            self.message.add_message(self.end_message)
            self.message.add_message('WYNIKI:')
            if self.players[0].bankrupt:
                self.message.add_message(f'{self.players[0].color}: BANKRUT')
                self.message.add_message('wynik: 0')
            else:
                field_money = 0
                field_houses= 0
                for field in self.board.fields:
                    if hasattr(field, 'owner'):
                        if field.owner == self.players[0]:
                            if hasattr(field, 'home_counter'):
                                field_houses += field.home_counter * field.att[9]
                                if field.home_counter > 4:
                                    field_houses += (field.home_counter-4) * (field.att[10]-field.att[9])
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1]/2)
                            else:
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1]/2)
                self.message.add_message(f'{self.players[0].color}: kasa: ${self.players[0].money}; warotść nieruchomości: ${field_money}')
                self.message.add_message(f'wynik: ${field_money + self.players[0].money}')

            if self.players[1].bankrupt:
                self.message.add_message(f'{self.players[1].color}: BANKRUT')
                self.message.add_message('wynik: 0')
            else:
                field_money = 0
                field_houses = 0
                for field in self.board.fields:
                    if hasattr(field, 'owner'):
                        if field.owner == self.players[1]:
                            if hasattr(field, 'home_counter'):
                                field_houses += field.home_counter * field.att[9]
                                if field.home_counter > 4:
                                    field_houses += (field.home_counter - 4) * (field.att[10] - field.att[9])
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1] / 2)
                            else:
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1] / 2)
                self.message.add_message(f'{self.players[1].color}: kasa: ${self.players[1].money}; warotść nieruchomości: ${field_money}')
                self.message.add_message(f'wynik: ${field_money+self.players[1].money}')

            if self.players[2].bankrupt:
                self.message.add_message(f'{self.players[2].color}: BANKRUT')
                self.message.add_message('wynik: 0')
            else:
                field_money = 0
                field_houses = 0
                for field in self.board.fields:
                    if hasattr(field, 'owner'):
                        if field.owner == self.players[2]:
                            if hasattr(field, 'home_counter'):
                                field_houses += field.home_counter * field.att[9]
                                if field.home_counter > 4:
                                    field_houses += (field.home_counter - 4) * (field.att[10] - field.att[9])
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1] / 2)
                            else:
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1] / 2)
                self.message.add_message(f'{self.players[2].color}: kasa: ${self.players[2].money}; warotść nieruchomości: ${field_money}')
                self.message.add_message(f'wynik: ${field_money+self.players[2].money}')

            if self.players[3].bankrupt:
                self.message.add_message(f'{self.players[3].color}: BANKRUT')
                self.message.add_message('wynik: 0')
            else:
                field_money = 0
                field_houses = 0
                for field in self.board.fields:
                    if hasattr(field, 'owner'):
                        if field.owner == self.players[3]:
                            if hasattr(field, 'home_counter'):
                                field_houses += field.home_counter * field.att[9]
                                if field.home_counter > 4:
                                    field_houses += (field.home_counter - 4) * (field.att[10] - field.att[9])
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1] / 2)
                            else:
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1] / 2)
                self.message.add_message(f'{self.players[3].color}: kasa: ${self.players[3].money}; warotść nieruchomości: ${field_money}')
                self.message.add_message(f'wynik: ${field_money+self.players[3].money}')

        bankrupt_count = 0
        for player in self.players:
            if player.bankrupt:
                bankrupt_count += 1

                for field in player.board.fields:
                    if hasattr(field, 'owner'):
                        if field.owner == player:
                            field.owner = None
                            field.mortgage = False
                            if hasattr(field, 'home_counter'):
                                field.home_counter = 0
        if bankrupt_count >= 2 and not self.game_over:
            self.game_over = True
            self.end_message = '@ KONIEC GRY - zostało 2 graczy'
            sound.END_SOUND.play(0)
            return

        if self.current_player_index != 0 and not self.game_over:
            self.dice_rolled = False
            self.round_counter += 1
            if self.players[self.current_player_index].player_action():
                self.switch_player()

        if self.dalej_button.click():
            clicked_field = self.board.get_clicked_field()
            if clicked_field is not None:
                clicked_field.clicked = False
            self.trade_mode = False
            self.dalej_button.set_visible(False)
            self.kup_button.set_visible(False)
            self.kupDom_button.set_visible(False)
            self.sprzedajDom_button.set_visible(False)
            self.zastaw_button.set_visible(False)
            self.wykup_button.set_visible(False)
            self.handel_button.set_visible(False)
            self.dalej_button.set_visible(False)

            if not self.players[self.current_player_index].bankrupt:
                self.round_counter += 1
            self.switch_player()
            return

        if self.rzut_button.click():
            clicked_field = self.board.get_clicked_field()
            if clicked_field is not None:
                clicked_field.clicked = False

            self.trade_mode = False
            self.dice_rolled = True
            self.rzut_button.set_visible(False)
            self.dalej_button.set_visible(True)

            self.dice.double_roll()
            self.message.add_message(f"wyrzuciłeś {self.dice.get_turn_value()}")
            self.message.show_message(self.screen)
            self.dice.draw(self.screen)
            pygame.time.delay(1000)
            pygame.display.update()

            self.players[self.current_player_index].move(self.dice.get_turn_value())
            # self.players[self.current_player_index].move(4)
            self.board.draw(self.screen)
            self.dice.draw(self.screen)
            pygame.display.update()
            return

        if self.kup_button.click():
            self.trade_mode = False
            actual_field = self.board.get_field(self.players[0].position)
            actual_field.owner = self.players[0]
            self.players[0].money -= actual_field.att[1]
            self.message.add_message(f'kupiłeś pole {actual_field.att[14]} za {actual_field.att[1]}')
            pygame.time.delay(200)
            sound.BUY_SOUND.play(0)
            return

        if self.zastaw_button.click():
            self.trade_mode = False
            self.zastaw_button.set_visible(False)
            clicked_field = self.board.get_clicked_field()
            clicked_field.mortgage = True
            clicked_field.clicked = False
            clicked_field.owner.money += int(clicked_field.att[1]/2)
            self.message.add_message(f'zastawiłeś pole {clicked_field.att[14]} (+ ${int(clicked_field.att[1]/2)})')
            pygame.time.delay(200)
            sound.BUY_SOUND.play(0)
            return

        if self.wykup_button.click():
            self.trade_mode = False
            self.wykup_button.set_visible(False)
            clicked_field = self.board.get_clicked_field()
            clicked_field.mortgage = False
            clicked_field.clicked = False
            clicked_field.owner.money -= int(clicked_field.att[1]*0.6)
            self.message.add_message(f'wykupiłeś pole {clicked_field.att[14]} (- ${int(clicked_field.att[1]*0.6)})')
            pygame.time.delay(200)
            sound.BUY_SOUND.play(0)
            return

        if self.kupDom_button.click():
            self.trade_mode = False
            self.kupDom_button.set_visible(False)
            clicked_field = self.board.get_clicked_field()
            clicked_field.clicked = False
            if clicked_field.home_counter < 4:
                clicked_field.owner.money -= int(clicked_field.att[9])
                clicked_field.home_counter += 1
                self.message.add_message(f'kupiłeś dom (- ${int(clicked_field.att[9])})')
            elif 3 < clicked_field.home_counter < 8:
                clicked_field.owner.money -= int(clicked_field.att[10])
                clicked_field.home_counter += 1
                self.message.add_message(f'kupiłeś hotel (- ${int(clicked_field.att[10])})')
            pygame.time.delay(200)
            sound.BUY_SOUND.play(0)
            return

        if self.sprzedajDom_button.click():
            self.trade_mode = False
            self.sprzedajDom_button.set_visible(False)
            clicked_field = self.board.get_clicked_field()
            clicked_field.clicked = False
            if clicked_field.home_counter < 5:
                clicked_field.owner.money += int(clicked_field.att[9]/2)
                clicked_field.home_counter -= 1
                self.message.add_message(f'sprzedałeś dom (- ${int(clicked_field.att[9] / 2)})')
            elif 4 < clicked_field.home_counter < 9:
                clicked_field.owner.money += int(clicked_field.att[10]/2)
                clicked_field.home_counter -= 1
                self.message.add_message(f'sprzedałeś hotel (- ${int(clicked_field.att[10]/2)})')
            pygame.time.delay(200)
            sound.BUY_SOUND.play(0)
            return

        if self.handel_button.click():
            pygame.time.delay(200)
            self.trade_money = 0
            clicked_field = self.board.get_clicked_field()
            self.trade_money += clicked_field.att[1]
            self.handel_button.set_visible(False)
            self.trade_mode = True
            return

        if self.handelnie.click():
            pygame.time.delay(200)
            clicked_field = self.board.get_clicked_field()
            clicked_field.clicked = False
            self.trade_mode = False
            return

        if self.handeltak.click():
            pygame.time.delay(200)
            self.trade_mode = False
            clicked_field = self.board.get_clicked_field()
            clicked_field.clicked = False
            clicked_field.owner.trade(self.players[0], clicked_field, self.trade_money)
            return

        if self.plus10.click():
            pygame.time.delay(200)
            if self.players[0].money <= self.trade_money+10:
                self.trade_money = self.players[0].money
            else:
                self.trade_money += 10
            return
        if self.plus100.click():
            pygame.time.delay(200)
            if self.players[0].money <= self.trade_money + 100:
                self.trade_money = self.players[0].money
            else:
                self.trade_money += 100
            return
        if self.minus10.click():
            pygame.time.delay(200)
            if self.trade_money <= 10:
                self.trade_money = 0
            else:
                self.trade_money -= 10
            return
        if self.minus100.click():
            pygame.time.delay(200)
            if self.trade_money <= 100:
                self.trade_money = 0
            else:
                self.trade_money -= 100
            return

        # ----------------------- warunki:

        if self.current_player_index == 0 and not self.dice_rolled:
            if self.players[0].bankrupt:
                self.rzut_button.set_visible(False)
                return

            if self.players[0].prison_counter > 0:
                self.message.add_message(f'@ odsiadujesz w więzieniu (zostało: {self.players[0].prison_counter})')
                self.message.show_message(self.screen)
                pygame.display.update()
                pygame.time.delay(1000)
                self.players[0].prison_counter -= 1
                self.switch_player()
                return
            self.rzut_button.set_visible(True)
            self.kup_button.set_visible(False)
            self.kupDom_button.set_visible(False)
            self.sprzedajDom_button.set_visible(False)
            self.zastaw_button.set_visible(False)
            self.wykup_button.set_visible(False)
            self.handel_button.set_visible(False)
            self.dalej_button.set_visible(False)
            return

        if self.current_player_index == 0 and self.dice_rolled and not self.players[0].bankrupt:
            # tutaj sprawdzanie co można robic na polu i właczanie przycisków podczas tury gracza
            # pole do kupienia
            actual_field = self.board.get_field(self.players[0].position)
            if hasattr(actual_field, 'owner'):
                if actual_field.owner is None and self.players[0].money >= actual_field.att[1]:
                    self.kup_button.set_visible(True)
                else:
                    self.kup_button.set_visible(False)

            # wyswietlanie przycisku zastaw/wykup
            self.zastaw_button.set_visible(False)
            self.wykup_button.set_visible(False)
            for field in self.board.fields:
                if hasattr(field, 'clicked') and hasattr(field, 'mortgage') and not hasattr(field, 'home_counter'):
                    if field.clicked and field.owner == self.players[0] and not field.mortgage:
                        self.zastaw_button.set_visible(True)
                    elif field.clicked and field.owner == self.players[0] and field.mortgage:
                        if field.owner.money > int(field.att[1]*0.6):
                            self.wykup_button.set_visible(True)
                elif hasattr(field, 'clicked') and hasattr(field, 'mortgage') and hasattr(field, 'home_counter'):
                    all_color_f = self.board.get_all_color_fields(field.name)
                    have_home = False
                    for x in all_color_f:
                        if x.home_counter > 0:
                            have_home = True
                    if field.clicked and field.owner == self.players[0] and not field.mortgage and not have_home:
                        self.zastaw_button.set_visible(True)
                    elif field.clicked and field.owner == self.players[0] and field.mortgage:
                        if field.owner.money > int(field.att[1]*0.6):
                            self.wykup_button.set_visible(True)

            # buy home/hotel
            self.kupDom_button.set_visible(False)
            for field in self.board.fields:
                if hasattr(field, 'clicked') and hasattr(field, 'mortgage') and hasattr(field, 'home_counter'):
                    if field.clicked:
                        all_color_f = self.board.get_all_color_fields(field.name)
                        have_monopol = True
                        home_count = field.home_counter
                        for x in all_color_f:
                            if x.owner != self.players[0] or x.mortgage:
                                have_monopol = False
                        if have_monopol and home_count < 4:
                            if self.players[0].money >= field.att[9]:
                                self.kupDom_button.set_visible(True)
                        elif have_monopol and 3 < home_count < 5:
                            if self.players[0].money >= field.att[10]:
                                self.kupDom_button.set_visible(True)

            # selling home
            self.sprzedajDom_button.set_visible(False)
            #print(self.board.get_field(2).clicked)
            for field in self.board.fields:
                if hasattr(field, 'clicked') and hasattr(field, 'mortgage') and hasattr(field, 'home_counter'):
                    if field.clicked and field.owner == self.players[0]:
                        home_count = field.home_counter
                        if 0 < home_count:
                            self.sprzedajDom_button.set_visible(True)

            # trade button
            self.handel_button.set_visible(False)
            for field in self.board.fields:
                if hasattr(field, 'clicked') and hasattr(field, 'owner'):
                    if field.clicked and field.owner != self.players[0] and field.owner is not None:
                        if hasattr(field, 'home_counter'):
                            all_color_f = self.board.get_all_color_fields(field.name)
                            home_count = field.home_counter
                            for x in all_color_f:
                                if x.home_counter != 0 and x.owner == field.owner:
                                    home_count += x.home_counter
                            if home_count == 0:
                                self.handel_button.set_visible(True)
                        else:
                            self.handel_button.set_visible(True)


    def _make_players(self):
        main_player = MainPlayer(self.selected_color, self)
        self.players.append(main_player)

        colors = ['red', 'blue', 'green', 'purple']
        colors.remove(self.selected_color)

        for color in colors:
            ai_player = AiPlayer(color, self)
            self.players.append(ai_player)

    def switch_player(self):
        if self.round_counter > 160:  # 160 -> 4 players * 40 rounds
            # self.message.add_message('@ koniec gry (więcej jak 40 rund)')
            self.end_message = '@ koniec gry (więcej jak 40 rund)'
            self.game_over = True
            sound.END_SOUND.play(0)
            return
        self.current_player_index = (self.current_player_index + 1) % len(self.players)
        if self.current_player_index == 0 and self.players[0].prison_counter == 0 and not self.players[0].bankrupt:
            self.message.add_message('@ twoja kolej:')
        elif self.current_player_index == 0 and self.players[0].bankrupt:
            self.current_player_index = (self.current_player_index + 1) % len(self.players)
