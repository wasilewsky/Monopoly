from .field import Field
import pygame


class Jail(Field):
    """
    representation of the 'jail' field
    """
    def __init__(self, index, pos_x, pos_y, image):
        super().__init__(index, 'jail', pos_x, pos_y, image)

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        pass

    def player_on_field_action(self, player):
        """
        player only visiting jail - nothing to do
        """
        pass


    def _draw_player(self, player, screen):
        if player.is_in_prison:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 60, self.pos_y + 20, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 80, self.pos_y + 20, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 60, self.pos_y + 40, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 80, self.pos_y + 40, 15, 15))
        else:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 13, self.pos_y + 25, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 13, self.pos_y + 55, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 50, self.pos_y + 88, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 80, self.pos_y + 88, 15, 15))
