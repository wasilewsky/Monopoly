import pygame, os

pygame.mixer.init()
path = os.path.join(os.pardir, 'Monopoly/sound')

BUTTON_SOUND1 = pygame.mixer.Sound(os.path.join(path, 'click_sound.wav'))
HITBOX_SOUND1 = pygame.mixer.Sound(os.path.join(path, 'choose_sound.wav'))
END_SOUND = pygame.mixer.Sound(os.path.join(path, 'przegrana.wav'))
BUY_SOUND = pygame.mixer.Sound(os.path.join(path, 'kup.wav'))
ROLL_SOUND = pygame.mixer.Sound(os.path.join(path, 'rzut.mp3'))
MOVE_SOUND = pygame.mixer.Sound(os.path.join(path, 'wolny_dzwiek1.wav'))
JAIL_SOUND = pygame.mixer.Sound(os.path.join(path, 'jail.wav'))
HOME_SOUND = pygame.mixer.Sound(os.path.join(path, 'dom.wav'))
CARD_SOUND = pygame.mixer.Sound(os.path.join(path, 'karta.wav'))

HITBOX_SOUND1.set_volume(0.1)
BUTTON_SOUND1.set_volume(0.1)
END_SOUND.set_volume(0.2)
BUY_SOUND.set_volume(0.2)
ROLL_SOUND.set_volume(0.2)
MOVE_SOUND.set_volume(0.2)
JAIL_SOUND.set_volume(0.2)
HOME_SOUND.set_volume(0.2)
CARD_SOUND.set_volume(0.2)
