import pygame

from monopoly import *

pygame.init()

os.environ['SDL_VIDEO_CENTERED'] = "1"
screen = pygame.display.set_mode(settings.SIZESCREEN, pygame.FULLSCREEN)


def game(selected_color):
    pygame.time.delay(200)
    esc_counter = 0
    game = Game(screen, selected_color)

    window_open = True
    while window_open:
        screen.blit(image.BACKGROUND, (0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                window_open = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    esc_counter += 1
                    if esc_counter == 2:
                        window_open = False
                    else:
                        game.game_over = True


        game.draw()
        pygame.display.flip()


def color():
    pygame.time.delay(150)
    window_open = True

    redBtn = Button(screen.get_width() / 2 - 300, 250, image.REDBTN, True)
    blueBtn = Button(screen.get_width() / 2 + 50, 250, image.BLUEBTN, True)
    greenBtn = Button(screen.get_width() / 2 - 300, 575, image.GREENBTN, True)
    purpleBtn = Button(screen.get_width() / 2 + 50, 575, image.PURPLEBTN, True)

    while window_open:
        screen.blit(image.BACKGROUND1, (0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                window_open = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    window_open = False

        if redBtn.click():
            window_open = False
            if not game("red"):
                window_open = True

        if blueBtn.click():
            window_open = False
            if not game("blue"):
                window_open = True
        if greenBtn.click():
            window_open = False
            if not game("green"):
                window_open = True
        if purpleBtn.click():
            window_open = False
            if not game("purple"):
                window_open = True

        redBtn.draw(screen)
        blueBtn.draw(screen)
        greenBtn.draw(screen)
        purpleBtn.draw(screen)

        pygame.display.flip()


def main():
    window_open = True
    logo = Button(screen.get_width() / 2 - image.TITLE.get_width() / 2, 100, image.TITLE, True)
    play_button = Button(screen.get_width() / 2 - image.START_BUTTON.get_width() / 2, 350, image.START_BUTTON, True)
    exit_button = Button(screen.get_width() / 2 - image.START_BUTTON.get_width() / 2, 650, image.EXIT_BUTTON, True)

    while window_open:
        screen.blit(image.BACKGROUND1, (0, 0))
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                window_open = False
            elif event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    window_open = False

        if play_button.click():
            window_open = False
            if not color():
                window_open = True

        if exit_button.click():
            window_open = False

        play_button.draw(screen)
        exit_button.draw(screen)
        logo.draw(screen)

        pygame.display.flip()


if __name__ == '__main__':
    main()

pygame.quit()
