import pygame.time
from .player import Player
from ..sound import *


class AiPlayer(Player):
    def __init__(self, color, game):
        super().__init__(color, game)
        self.dice = game.dice
        self.game_over = game.game_over
        self.field_to_buy_home = None
        self.field_to_trade = None
        self.trade_money = 0
        self.done_trade_fields = []
        self.monopol_fields = None


    def player_action(self):
        if self.prison_counter == 0:
            self.is_in_prison = False
        if self.bankrupt:
            return True
        if self.is_in_prison:
            self.message.add_message(f"@ tura gracza {self.color}")
            self.message.show_message(self.screen)
            pygame.display.update()
            pygame.time.delay(1000)
            self.message.add_message(f"@ gracz {self.color} odsiaduje w więzieniu. (zostało {self.prison_counter})")
            self.message.show_message(self.screen)
            pygame.display.update()
            pygame.time.delay(1000)
            self.prison_counter -= 1
            return True
        if self.game_over:
            return True

        self.message.add_message(f"@ tura gracza {self.color}")
        self.message.show_message(self.screen)
        pygame.display.update()

        self.dice.double_roll()

        pygame.time.delay(1000)
        self.message.add_message(f"gracz {self.color} wyrzucił {self.dice.get_turn_value()}")
        self.message.show_message(self.screen)
        self.dice.draw(self.screen)
        pygame.display.update()

        pygame.time.delay(1000)
        self.move(self.dice.get_turn_value())
        #self.move(4)
        pygame.display.update()


        self.select_action(self.evaluate())


        return True

    def evaluate(self):
        w = [0] * 4  # - zbiór wartości akcji

        standing_field = self.board.get_field(self.position)
        color_fields_count = 0
        color_field_else_owner = 0
        field_value = 0
        houses_on_others_fields = False
        monopol = False
        same_owner_else_fields = False # czy ten sam gracz jest właścicielem wszystkich pól poza tym co stoimy
        else_owner = None # do sprawdzania same_owner_else_fields
        field_count = 0   # liczba pól danego typu/koloru co stoimy

        if hasattr(standing_field, 'home_counter'):
            for field in self.board.get_all_color_fields(standing_field.name):
                field_count += 1
                if field.owner == self:
                    color_fields_count += 1
                if field.owner is not None and field.owner != self:
                    if else_owner is None:
                        else_owner = field.owner
                    else:
                        if else_owner == field.owner:
                            same_owner_else_fields = True
                        else:
                            same_owner_else_fields = False
                    color_field_else_owner += 1

            if standing_field.name == 'red':
                field_value = 100
            if standing_field.name == 'yellow':
                field_value = 40
            if standing_field.name == 'green':
                field_value = 20
            if standing_field.name == 'darkblue':
                field_value = 20
            if standing_field.name == 'orange':
                field_value = 100
            if standing_field.name == 'pink':
                field_value = 40
            if standing_field.name == 'lightblue':
                field_value = 20
            if standing_field.name == 'brown':
                field_value = 20
        if hasattr(standing_field, 'owner') and not hasattr(standing_field, 'home_counter'):
            if standing_field.name == 'satellite':
                field_count += 1
                for field in self.board.fields:
                    if field.name == 'satellite':
                        field_count += 1
                        if field.owner == self:
                            color_fields_count += 1
                        if field.owner is not None and field.owner != self:
                            if else_owner is None:
                                else_owner = field.owner
                            else:
                                if else_owner == field.owner:
                                    same_owner_else_fields = True
                                else:
                                    same_owner_else_fields = False
                            color_field_else_owner += 1

                field_value = 10
            if standing_field.name == 'powerstation':
                for field in self.board.fields:
                    field_count += 1
                    if field.name == 'powerstation':
                        field_count += 1
                        if field.owner == self:
                            color_fields_count += 1
                        if field.owner is not None and field.owner != self:
                            if else_owner is None:
                                else_owner = field.owner
                            else:
                                if else_owner == field.owner:
                                    same_owner_else_fields = True
                                else:
                                    same_owner_else_fields = False
                            color_field_else_owner += 1

                field_value = 15

        field_amount = 0
        for field in self.board.fields:
            if hasattr(field, 'owner'):
                if field.owner == self:
                    field_amount += 1


        # === kupowanie pola w(0) ===

        if not hasattr(standing_field, 'owner'):
            w[0] = 0
        elif standing_field.owner is not None:
            w[0] = 0
        elif self.money <= standing_field.att[1]:
            w[0] = 0
        else:
            # heat map impact
            w[0] = field_value

            # jeśli gracz ma mało pol
            if field_amount < 3:
                w[0] += 50


            # myself field count impact
            if color_fields_count == 0:
                w[0] -= 20
            elif color_fields_count == 1:
                w[0] += 30
            elif color_fields_count == 2:
                w[0] += 50

            # else player field count impact
            if color_field_else_owner == 0:
                w[0] += 10
            elif color_field_else_owner == 1:
                w[0] -= 30
            elif color_field_else_owner == 2:
                if same_owner_else_fields:
                    w[0] += 50
                else:
                    w[0] -= 50

            # money vs cost impact
            if standing_field.att[1] < self.money < 1.5 * standing_field.att[1]:
                w[0] -= 10
            elif 1.5 * standing_field.att[1] <= self.money < 2.5 * standing_field.att[1]:
                w[0] += 20
            elif 2.5 * standing_field.att[1] <= self.money < 4 * standing_field.att[1]:
                w[0] += 50
            else:
                w[0] += 70

            # turn count impact
            w[0] += self.turn_counter

        print('===========')
        print(f'w[0] kup pole: {w[0]}')




        # === odkupowanie pola w(1) ===

        for field in self.board.fields:
            if hasattr(field, 'mortgage'):
                if field.mortgage and field.owner == self:
                    w[1] = int(self.money / 20)

        print('===========')
        print(f'w[1] odkup pole: {w[1]}')




        # === propozycja handlu w(2) ===

        field_to_trade = None
        else_owner_field_counter = 0
        not_owner_field_counter = 0

        end = False
        for field in self.board.fields:
            if hasattr(field, 'home_counter'):
                color_fields = self.board.get_all_color_fields(field.name)
                if not end:
                    else_owner_field_counter = 0
                    not_owner_field_counter = 0
                    for f in color_fields:
                        if f.owner is not None and f.owner != self:
                            else_owner_field_counter += 1
                            field_to_trade = f
                        elif f.owner is None:
                            not_owner_field_counter += 1
                            field_to_trade = None
                    if else_owner_field_counter == 1 and not_owner_field_counter == 0:
                        end = True
                        print('is end')

        if end:
            print('end')
            field_value = 0
            if field_to_trade.name == 'red':
                field_value = 100
            if field_to_trade.name == 'yellow':
                field_value = 40
            if field_to_trade.name == 'green':
                field_value = 20
            if field_to_trade.name == 'darkblue':
                field_value = 20
            if field_to_trade.name == 'orange':
                field_value = 100
            if field_to_trade.name == 'pink':
                field_value = 40
            if field_to_trade.name == 'lightblue':
                field_value = 20
            if field_to_trade.name == 'brown':
                field_value = 20

        if else_owner_field_counter != 1 or not_owner_field_counter > 0:
            w[2] = 0
        elif field_to_trade in self.done_trade_fields:
            w[2] = 0
        else:
            print(f'weszło do szacowania {field_to_trade.index}')

            w[2] = 30
            if field_to_trade.att[1] < self.money < 1.5 * field_to_trade.att[1]:
                w[2] -= 20
                w[2] += field_value / 3
            elif 1.5 * field_to_trade.att[1] <= self.money < 4 * field_to_trade.att[1]:
                w[2] += 10
                w[2] += field_value / 2.5
            else:
                w[2] += 20
                w[2] += field_value / 2


            trade_money = int(field_to_trade.att[1] * 1.6)



            if trade_money >= self.money:
                w[2] = 0
            if field_to_trade in self.done_trade_fields:
                if self.trade_money >= trade_money:
                    print(f'zerowanie bo jest w tablicy {field_to_trade}')
                    print(f'zerowanie bo jest w tablicy {self.done_trade_fields}')
                    w[2] = 0

            if w[2] != 0:
                if field_to_trade.owner != self and self.money > trade_money:
                    print('wpisało')
                    self.field_to_trade = field_to_trade
                    self.trade_money = trade_money
                    print(f'{self.field_to_trade.index}')
                else:
                    w[2] = 0


        print('===========')
        print(f'w[2] prop pola: {w[2]}')

        # === buduj budynek w(3) ===

        monopol_color = None

        end = False
        for field in self.board.fields:
            if hasattr(field, 'home_counter'):
                color_fields = self.board.get_all_color_fields(field.name)
                if not end:
                    else_owner_field_counter = 0
                    not_owner_field_counter = 0
                    for f in color_fields:
                        if f.owner is not None and f.owner != self:
                            else_owner_field_counter += 1
                        elif f.owner is None:
                            not_owner_field_counter += 1
                    if else_owner_field_counter == 0 and not_owner_field_counter == 0:
                        end = True
                        monopol_color = color_fields
                        print(f'is end (monopol= {monopol_color[0].name})')
                    else:
                        w[3] = 0

        if end:
            print('end (monopol)')
            field_value = 0
            if monopol_color[0].name == 'red':
                field_value = 100
            if monopol_color[0].name == 'yellow':
                field_value = 40
            if monopol_color[0].name == 'green':
                field_value = 20
            if monopol_color[0].name == 'darkblue':
                field_value = 20
            if monopol_color[0].name == 'orange':
                field_value = 100
            if monopol_color[0].name == 'pink':
                field_value = 40
            if monopol_color[0].name == 'lightblue':
                field_value = 20
            if monopol_color[0].name == 'brown':
                field_value = 20

            w[3] = int(field_value/2)

            if self.money <= 500:
                w[3] += 10
            elif self.money <= 700:
                w[3] += 20
            elif self.money <= 900:
                w[3] += 30
            elif self.money <= 1100:
                w[3] += 40
            else:
                w[3] += 50

            if self.money < 300:
                w[3] = 0


        if w[3] > 0:
            all_hotels = False
            for field in monopol_color:
                if field.home_counter == 5:
                    all_hotels = True
            if all_hotels or self.money < 300:
                w[3] = 0
            else:
                self.monopol_fields = monopol_color

        print('===========')
        print(f'w[3] buduj budyneka: {w[3]}')

        print(f'w = {w}')
        return w

    def select_action(self, w):
        max_action_value = max(w)
        w2 = None
        print(f'max value {max_action_value}')
        while max_action_value >= 50:
            pygame.time.delay(1000)
            if w2 is None:
                w2 = w
            self.make_action(w2.index(max_action_value))
            w2 = self.evaluate()
            max_action_value = max(w2)
            print(f'max value2: {max_action_value}')
        print(f'===={self.color}=====')
        print('==========')

    def make_action(self, index):
        standing_field = self.board.get_field(self.position)

        if index == 0:
            # akcja 0 kupowanie pola
            self.money -= standing_field.att[1]
            standing_field.owner = self
            sound.BUY_SOUND.play(0)
            self.message.add_message(f'gracz {self.color} kupuje pole {standing_field.att[14]} (- ${standing_field.att[1]})')
            self.message.show_message(self.screen)
            self.info_table.draw()
            self.board.draw(self.screen)
            self.dice.draw(self.screen)
            pygame.display.update()
            pygame.time.delay(1000)

        if index == 1:
            print(f'robi w[1] dla gracza {self.color}')
            field = None
            for f in self.board.fields:
                if hasattr(f, 'owner'):
                    if f.owner == self and f.mortgage:
                        if field is None:
                            field = f
                        else:
                            field_value, f_value = 0, 0
                            if field.name == 'red':
                                field_value = 100
                            if field.name == 'yellow':
                                field_value = 40
                            if field.name == 'green':
                                field_value = 20
                            if field.name == 'darkblue':
                                field_value = 20
                            if field.name == 'orange':
                                field_value = 100
                            if field.name == 'pink':
                                field_value = 40
                            if field.name == 'lightblue':
                                field_value = 20
                            if field.name == 'brown':
                                field_value = 20
                            if field.name == 'satellite':
                                field_value = 10
                            if field.name == 'powerstation':
                                field_value = 15

                            if f.name == 'red':
                                f_value = 100
                            if f.name == 'yellow':
                                f_value = 40
                            if f.name == 'green':
                                f_value = 20
                            if f.name == 'darkblue':
                                f_value = 20
                            if f.name == 'orange':
                                f_value = 100
                            if f.name == 'pink':
                                f_value = 40
                            if f.name == 'lightblue':
                                f_value = 20
                            if f.name == 'brown':
                                f_value = 20
                            if f.name == 'satellite':
                                f_value = 10
                            if f.name == 'powerstation':
                                f_value = 15

                            if f_value > field_value:
                                field = f

            field.mortgage = False
            self.money -= int(field.att[1]*0.6)
            sound.BUY_SOUND.play(0)
            self.message.add_message(f'gracz {self.color} wykupuje pole {field.att[14]} (- ${int(field.att[1]*0.6)})')
            self.message.show_message(self.screen)
            self.info_table.draw()
            self.board.draw(self.screen)
            pygame.display.update()
            pygame.time.delay(1000)

        if index == 2:
            print('akcja 2')
            owner = self.field_to_trade.owner
            if owner == owner.players[0]:
                self.done_trade_fields.append(self.field_to_trade)
            else:
                print(f'faktyczne wywałanie trade: dla {self.field_to_trade.index}')
                pygame.time.delay(1000)
                owner.trade(self, self.field_to_trade, self.trade_money)
                self.done_trade_fields.append(self.field_to_trade)


        if index == 3:
            print('akcja 3')

            build = False
            x = 0
            while not build and x < 5:
                for c in self.monopol_fields:
                    if c.home_counter == x:
                        c.home_counter += 1
                        if c.home_counter < 5:
                            self.money -= c.att[9]
                            self.message.add_message(
                            f'gracz {self.color} wykupuje domek (- ${c.att[9]})')
                            self.message.show_message(self.screen)
                            self.info_table.draw()
                            self.board.draw(self.screen)
                            self.dice.draw(self.screen)
                            pygame.display.update()
                            sound.HOME_SOUND.play(0)
                            pygame.time.delay(1000)
                        else:
                            self.money -= c.att[10]
                            self.message.add_message(
                                f'gracz {self.color} wykupuje hotel (- ${c.att[10]})')
                            self.message.show_message(self.screen)
                            self.info_table.draw()
                            self.board.draw(self.screen)
                            self.dice.draw(self.screen)
                            pygame.display.update()
                            sound.HOME_SOUND.play(0)
                            pygame.time.delay(1000)
                        build = True
                x += 1





    def trade(self, player, field, money):
        self.message.add_message(f'gracz {player.color} chce kupić pole {field.att[14]} za {money}')
        self.message.show_message(self.screen)
        pygame.display.update()
        pygame.time.delay(1000)
        print(f'przyszło field {field.index}')


        self_fields_count = 0
        field_value = 0
        monopol = False
        field_count = 0  # liczba pól danego typu/koloru co stoimy

        if hasattr(field, 'home_counter'):
            for f in self.board.get_all_color_fields(field.name):
                field_count += 1
                if f.owner == self:
                    self_fields_count += 1

            if field.name == 'red':
                field_value = 100
            if field.name == 'yellow':
                field_value = 40
            if field.name == 'green':
                field_value = 20
            if field.name == 'darkblue':
                field_value = 20
            if field.name == 'orange':
                field_value = 100
            if field.name == 'pink':
                field_value = 40
            if field.name == 'lightblue':
                field_value = 20
            if field.name == 'brown':
                field_value = 20

        if hasattr(field, 'owner') and not hasattr(field, 'home_counter'):
            if field.name == 'satellite':
                for f in self.board.fields:
                    if f.name == 'satellite':
                        field_count += 1
                        if field.owner == self:
                            self_fields_count += 1
                field_value = 10

            if field.name == 'powerstation':
                for f in self.board.fields:
                    if f.name == 'powerstation':
                        field_count += 1
                        if f.owner == self:
                            self_fields_count += 1
                field_value = 15

        if field_count == self_fields_count:
            monopol = True

        decision = False

        if monopol:
            if self.money <= 200:
                decision = True
        else:
            if self_fields_count == 1 and field_value < 100:
                if self.money <= 200:
                    if money >= field.att[1] * 1.1:
                        decision = True
                elif self.money <= 600:
                    if money >= field.att[1] * 1.2:
                        decision = True
                elif self.money <= 800:
                    if money >= field.att[1] * 1.3:
                        decision = True
                elif self.money > 1000:
                    if money >= field.att[1] * 1.5:
                        decision = True

            elif self_fields_count == 1 and field_value == 100:
                if self.money <= 200:
                    if money >= field.att[1] * 1.1:
                        decision = True
                elif self.money <= 600:
                    if money >= field.att[1] * 1.2:
                        decision = True
                elif self.money <= 800:
                    if money >= field.att[1] * 1.3:
                        decision = True

            elif self_fields_count == 2 and field_value < 100:
                if self.money <= 200:
                    if money >= field.att[1] * 1.2:
                        decision = True
                elif self.money <= 600:
                    if money >= field.att[1] * 1.3:
                        decision = True

            elif self_fields_count == 2 and field_value == 100:
                if self.money <= 200:
                    if money >= field.att[1] * 1.5:
                        decision = True

        print(f'przyszło field {field.index}')


        if decision:
            self.message.add_message(f'gracz {self.color} przyjmuje propozycję')
            self.message.show_message(self.screen)
            field.owner = player
            self.money += money
            player.money -= money
            self.info_table.draw()
            pygame.display.update()
            pygame.time.delay(1000)
            print(f'zmiana wlaściciela {self.color} pola {field.index} na gracza {player.color}')

        else:
            self.message.add_message(f'gracz {self.color} odrzuca propozycję')
            self.message.show_message(self.screen)
            pygame.display.update()
            pygame.time.delay(1000)

