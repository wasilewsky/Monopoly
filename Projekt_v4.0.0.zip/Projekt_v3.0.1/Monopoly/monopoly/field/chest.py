import pygame
import random
from .field import Field
from ..sound import *
from ..settings import cards


class Chest(Field):
    """
    representation of the 'chest' field
    """
    def __init__(self, index, pos_x, pos_y, image):
        super().__init__(index, 'chest', pos_x, pos_y, image)

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        pass

    def player_on_field_action(self, player):
        chance_card = random.choice(cards)
        sound.CARD_SOUND.play(0)
         # print(chance_card)
        #chance_card = cards[7]
        card_number, card_description = chance_card
        # print(f"Player {player.color} drew card {card_number}: {card_description}")

        pygame.draw.rect(self.screen, 'WHITE', (530, 550, 286, 176), 0, 10, -10, -10, -10,
                         -10)  # tło karty
        pygame.draw.rect(self.screen, (0, 0, 0), (533, 553, 280, 170), 2, 10, -10, -10, -10,
                         -10)  # ramka
        text5 = pygame.font.Font.render(pygame.font.SysFont(None, 40), f"KARTA SZANSY", True, (0, 0, 0))
        self.screen.blit(text5, (567, 574))

        card_description = card_description.replace(',', '.')
        card_description = card_description.replace('!', '.')
        if '.' in card_description:
            card_description1, card_description2 = card_description.split('.', 1)
        else:
            card_description1 = card_description
            card_description2 = ""

        text5 = pygame.font.Font.render(pygame.font.SysFont(None, 22), card_description1, True, (0, 0, 0))
        text_rect = text5.get_rect(center=(530 + 286 // 2, 635))
        self.screen.blit(text5, text_rect)

        text5 = pygame.font.Font.render(pygame.font.SysFont(None, 22), card_description2, True, (0, 0, 0))
        text_rect = text5.get_rect(center=(530 + 286 // 2, 665))
        self.screen.blit(text5, text_rect)

        pygame.display.update()
        pygame.time.delay(2000)

        if card_number == 1:  # ZA KAZDY DOM $40 A ZA HOTEL $115
            field_houses = 0
            field_hotels = 0
            for field in player.board.fields:
                if hasattr(field, 'owner'):
                    if field.owner == player:
                        if hasattr(field, 'home_counter'):
                            field_houses += field.home_counter
                            if field.home_counter > 4:
                                hotels = field.home_counter - 4
                                field_houses -= hotels
                                field_hotels += hotels

            if player.money < field_houses * 40 + field_hotels * 115:
                player.repossession(field_houses * 40 + field_hotels * 115)
                if player.money < field_houses * 40 + field_hotels * 115:
                    player.bankrupt = True
                    return f'gracz {player.color} bankrutuje'
                else:
                    if field_hotels > 0 or field_houses > 0:
                        sound.BUY_SOUND.play(0)
                    player.money -= field_houses * 40 + field_hotels * 115
            else:
                if field_hotels > 0 or field_houses > 0:
                    sound.BUY_SOUND.play(0)
                player.money -= field_houses * 40 + field_hotels * 115
        elif card_number == 2:
            sound.BUY_SOUND.play(0)
            player.money += 10
            pass
        elif card_number == 3:
            sound.BUY_SOUND.play(0)
            player.money += 200
            pass
        elif card_number == 4:  # KARTA WYJSCIA Z WIEZIENIA
            player.jail_free_card = True
        elif card_number == 5:  # IDZ DO WIEZIENIA
            step = 31 - player.position
            if step < 0:
                step = 40 + step
            player.move(step, False)
        elif card_number == 6:
            for p in player.players:
                if p.money < 10 and p != player:
                    p.repossession(10)
                    if p.money < 10:
                        p.bankrupt = True
                        #return f'gracz {player.color} bankrutuje'
                    else:
                        p.money -= 10
                        player.money += 10
                else:
                    p.money -= 10
                    player.money += 10
            sound.BUY_SOUND.play(0)
        elif card_number == 7:
            sound.BUY_SOUND.play(0)
            player.money += 100
        elif card_number == 8:
            if player.money < 100:
                player.repossession(100)
                if player.money < 100:
                    player.bankrupt = True
                    return f'gracz {player.color} bankrutuje'
                else:
                    sound.BUY_SOUND.play(0)
                    player.money -= 100
            else:
                sound.BUY_SOUND.play(0)
                player.money -= 100
        elif card_number == 9:
            if player.money < 50:
                player.repossession(50)
                if player.money < 50:
                    player.bankrupt = True
                    return f'gracz {player.color} bankrutuje'
                else:
                    sound.BUY_SOUND.play(0)
                    player.money -= 50
            else:
                sound.BUY_SOUND.play(0)
                player.money -= 50
        elif card_number == 10:
            step = 1 - player.position
            if step < 0:
                step = 40 + step
            player.move(step)
        elif card_number == 11:
            sound.BUY_SOUND.play(0)
            player.money += 50
        elif card_number == 12:
            if player.money < 50:
                player.repossession(50)
                if player.money < 50:
                    player.bankrupt = True
                    return f'gracz {player.color} bankrutuje'
                else:
                    sound.BUY_SOUND.play(0)
                    player.money -= 50
            else:
                sound.BUY_SOUND.play(0)
                player.money -= 50
        elif card_number == 13:
            sound.BUY_SOUND.play(0)
            player.money += 20
        elif card_number == 14:
            sound.BUY_SOUND.play(0)
            player.money += 25
        elif card_number == 15:
            sound.BUY_SOUND.play(0)
            player.money += 100
        elif card_number == 16:
            sound.BUY_SOUND.play(0)
            player.money += 100

        pygame.time.delay(1000)

    def _draw_player(self, player, screen):
        if self.index == 3:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

        if self.index == 18:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 30, self.pos_y + 18, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 50, self.pos_y + 18, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 30, self.pos_y + 38, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 50, self.pos_y + 38, 15, 15))

        if self.index == 34:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 40, self.pos_y + 18, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 60, self.pos_y + 18, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 40, self.pos_y + 38, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 60, self.pos_y + 38, 15, 15))
