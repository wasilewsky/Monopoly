from ..field import *
from ..image import *
from ..settings import *


class Board:
    def __init__(self):
        self.fields = []
        self._build_board()
        self.another_field = False


    def _build_board(self):
        base_y = screen.get_height()/2 - (2 * image.POLEPARKING.get_height() + 9 * image.POLEGREEN.get_height())/2
        base_x = screen.get_width()/2 - (2 * image.POLEPARKING.get_width() + 9 * image.POLERED.get_width())
        x, y = base_x, base_y

        # 21 parking
        field = Parking(21, x, y, image.POLEPARKING)
        x += field.image.get_width()
        self.fields.append(field)

        # 22 image.POLERED
        field = Street(22, x, y, image.POLERED, 'red', FIELDS_ATT[22], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 23 image.POLESZANSAGORA
        field = Chance(23, x, y, image.POLESZANSAGORA)
        x += field.image.get_width()
        self.fields.append(field)

        # 24 image.POLERED
        field = Street(24, x, y, image.POLERED, 'red', FIELDS_ATT[24], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 25 image.POLERED
        field = Street(25, x, y, image.POLERED, 'red', FIELDS_ATT[25], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 26 image.POLESATELITAN
        field = Satellite(26, x, y, image.POLESATELITAN, FIELDS_ATT[26], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 27 image.POLEYELLOW
        field = Street(27, x, y, image.POLEYELLOW, 'yellow', FIELDS_ATT[27], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 28 image.POLEYELLOW
        field = Street(28, x, y, image.POLEYELLOW, 'yellow', FIELDS_ATT[28], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 29 image.POLEELEKTROATOM
        field = PowerStation(29, x, y, image.POLEELEKTROATOM, FIELDS_ATT[29], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 30 image.POLEYELLOW
        field = Street(30, x, y, image.POLEYELLOW, 'yellow', FIELDS_ATT[30], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 31 image.POLEGOTOJAIL
        field = GoToJail(31, x, y, image.POLEGOTOJAIL)
        y += field.image.get_height()
        self.fields.append(field)

        # =====================================================

        # 32
        field = Street(32, x, y, image.POLEGREEN, 'green', FIELDS_ATT[32], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 33
        field = Street(33, x, y, image.POLEGREEN, 'green', FIELDS_ATT[33], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 34
        field = Chest(34, x, y, image.POLEKASAPRAWO)
        y += field.image.get_height()
        self.fields.append(field)

        # 35
        field = Street(35, x, y, image.POLEGREEN, 'green', FIELDS_ATT[35], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 36
        field = Satellite(36, x, y, image.POLESATELITAE, FIELDS_ATT[36], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 37
        field = Chance(37, x, y, image.POLESZANSAPRAWO)
        y += field.image.get_height()
        self.fields.append(field)

        # 38
        field = Street(38, x, y, image.POLEDARKBLUE, 'darkblue', FIELDS_ATT[38], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 39
        field = Tax(39, x, y, image.POLETAX)
        y += field.image.get_height()
        self.fields.append(field)

        # 40
        field = Street(40, x, y, image.POLEDARKBLUE, 'darkblue', FIELDS_ATT[40], screen)

        self.fields.append(field)

        # =====================================================
        x = base_x
        y = base_y + image.POLEPARKING.get_height()

        # 20
        field = Street(20, x, y, image.POLEORANGE, 'orange', FIELDS_ATT[20], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 19
        field = Street(19, x, y, image.POLEORANGE, 'orange', FIELDS_ATT[19], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 18
        field = Chest(18, x, y, image.POLEKASALEWO)
        y += field.image.get_height()
        self.fields.append(field)

        # 17
        field = Street(17, x, y, image.POLEORANGE, 'orange', FIELDS_ATT[17], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 16
        field = Satellite(16, x, y, image.POLESATELITAW, FIELDS_ATT[16], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 15
        field = Street(15, x, y, image.POLEPINK, 'pink', FIELDS_ATT[15], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 14
        field = Street(14, x, y, image.POLEPINK, 'pink', FIELDS_ATT[14], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 13
        field = PowerStation(13, x, y, image.POLEELEKTROSLON, FIELDS_ATT[13], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 12
        field = Street(12, x, y, image.POLEPINK, 'pink', FIELDS_ATT[12], screen)
        y += field.image.get_height()
        self.fields.append(field)

        # 11
        field = Jail(11, x, y, image.POLEJAIL)
        x += field.image.get_width()
        self.fields.append(field)

        # =====================================================

        # 10
        field = Street(10, x, y, image.POLELIGHTBLUE, 'lightblue', FIELDS_ATT[10], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 9
        field = Street(9, x, y, image.POLELIGHTBLUE, 'lightblue', FIELDS_ATT[9], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 8
        field = Chance(8, x, y, image.POLESZANSADOL)
        x += field.image.get_width()
        self.fields.append(field)

        # 7
        field = Street(7, x, y, image.POLELIGHTBLUE, 'lightblue', FIELDS_ATT[7], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 6
        field = Satellite(6, x, y, image.POLESATELITAS, FIELDS_ATT[6], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 5
        field = Tax(5, x, y, image.POLETAXDOL)
        x += field.image.get_width()
        self.fields.append(field)

        # 4
        field = Street(4, x, y, image.POLEBROWN, 'brown', FIELDS_ATT[4], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 3
        field = Chest(3, x, y, image.POLEKASADOL)
        x += field.image.get_width()
        self.fields.append(field)

        # 2
        field = Street(2, x, y, image.POLEBROWN, 'brown', FIELDS_ATT[2], screen)
        x += field.image.get_width()
        self.fields.append(field)

        # 1
        field = Start(1, x, y, image.POLESTART)
        x += field.image.get_width()
        self.fields.append(field)


    def get_field(self, number):
        for field in self.fields:
            if field.index == number:
                return field

    def get_clicked_field(self):
        for field in self.fields:
            if hasattr(field, 'clicked'):
                if field.clicked:
                    return field

    def get_all_color_fields(self, name):
        all_color_fields = []
        for field in self.fields:
            if hasattr(field, 'name'):
                if field.name == name:
                    all_color_fields.append(field)
        return all_color_fields

    def draw(self, screen):
        pygame.draw.rect(screen, '#cde6d0', (150, 150, 750, 750))
        for field in self.fields:
            field.draw(screen)
            clicked = field.field_clicked()
            field.field_mouse_on()

            # implementation remove actual border if click another field
            if clicked is not None:
                for field in self.fields:
                    if hasattr(field, 'clicked'):
                        if field.clicked and field.index != clicked.index:
                            field.clicked = False
                self.another_field = True

