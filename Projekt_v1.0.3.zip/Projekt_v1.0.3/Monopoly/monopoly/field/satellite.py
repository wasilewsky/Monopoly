import pygame
from .field import Field


class Satellite(Field):
    """
    representation of the 'satellite' field
    """
    def __init__(self, index, pos_x, pos_y, image, screen):
        super().__init__(index, 'satellite', pos_x, pos_y, image)
        self.hitbox = pygame.Rect(self.pos_x, self.pos_y, self.image.get_width(), self.image.get_height())
        self.screen = screen

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        # TODO napis
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            czcionka = pygame.font.SysFont("georgia", 20)
            text = "opis"
            text_render = czcionka.render(text, 1, (250, 250, 250))
            self.screen.blit(text_render, (200, 600))

    def player_on_field_action(self):
        # TODO opcja kupienia
        pass
