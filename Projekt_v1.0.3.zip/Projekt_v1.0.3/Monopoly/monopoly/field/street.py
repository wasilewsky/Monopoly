import pygame
from .field import Field


class Street(Field):
    """
    representation of the 'street' field
    """
    def __init__(self, index, pos_x, pos_y, image, color, att, screen):
        super().__init__(index, f'{color}', pos_x, pos_y, image)
        self.hitbox = pygame.Rect(self.pos_x, self.pos_y, self.image.get_width(), self.image.get_height())
        self.owner = None
        self.att = att
        self.screen = screen

    def field_clicked(self):
        # TODO opcje do wykonania z polem
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            if pygame.mouse.get_pressed()[0]:
                czcionka = pygame.font.SysFont("georgia", 20)
                text = "cena:" + str(self.att[1])
                text_render = czcionka.render(text, 1, (250, 250, 250))
                self.screen.blit(text_render, (200, 630))

    def field_mouse_on(self):
        # TODO wyświetlanie informacji dokończyć
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            czcionka = pygame.font.SysFont("georgia", 20)
            text = "nazwa:" + self.att[14]
            text_render = czcionka.render(text, 1, (250, 250, 250))
            self.screen.blit(text_render, (200, 600))

    def player_on_field_action(self):
        # TODO gracz płaci właścicielowi
        pass
