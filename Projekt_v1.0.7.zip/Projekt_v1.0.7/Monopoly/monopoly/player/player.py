import pygame


class Player:
    def __init__(self, color, game):
        """
        constructor
        """
        self.color = color
        self.money = 1500
        self.position = 1
        self.is_in_prison = False
        self.board = game.board
        self.screen = game.screen
        self.message = game.message
        self.dice = game.dice
        self.info_table = game.info_table
        self.is_moving = False
        self.move(0)  # need to first draw

    def player_action(self):
        raise Exception("player_action() not implemented")

    def move(self, step):
        self.is_moving = True
        actual_field = self.board.get_field(self.position)
        actual_field.add_player(self)

        for x in range(step):
            actual_field = self.board.get_field(self.position)
            actual_field.remove_player(self)
            self.position += 1
            if self.position > 40:
                self.position -= 40
                self.money += 200
                self.message.add_message(f"gracz o kolorze {self.color} przeszeł przez START (+ $200)")
                self.message.show_message(self.screen)
                self.info_table.draw()
                pygame.display.update()
            actual_field = self.board.get_field(self.position)
            actual_field.add_player(self)
            self.board.draw(self.screen)
            self.dice.draw(self.screen)
            pygame.display.update()
            pygame.time.delay(200)

        action_message = actual_field.player_on_field_action(self)
        if action_message:
            self.message.add_message(action_message)

        self.is_moving = False
