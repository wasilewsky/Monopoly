from .field import Field
import pygame


class Jail(Field):
    """
    representation of the 'jail' field
    """
    def __init__(self, index, pos_x, pos_y, image):
        super().__init__(index, 'jail', pos_x, pos_y, image)

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        pass

    def player_on_field_action(self, player):
        """
        player only visiting jail - nothing to do
        """
        pass


    def _draw_player(self, player, screen):
        if player.is_in_prison:
            if player.color == 'red':
                pygame.draw.rect(screen, 'RED', (self.pos_x + 13, self.pos_y + 25, 15, 15))
            if player.color == 'blue':
                pygame.draw.rect(screen, 'BLUE', (self.pos_x + 50, self.pos_y + 88, 15, 15))
            if player.color == 'green':
                pygame.draw.rect(screen, 'GREEN', (self.pos_x + 13, self.pos_y + 55, 15, 15))
            if player.color == 'purple':
                pygame.draw.rect(screen, 'PURPLE', (self.pos_x + 80, self.pos_y + 88, 15, 15))
        else:
            if player.color == 'red':
                pygame.draw.rect(screen, 'RED', (self.pos_x + 13, self.pos_y + 25, 15, 15))
            if player.color == 'blue':
                pygame.draw.rect(screen, 'BLUE', (self.pos_x + 50, self.pos_y + 88, 15, 15))
            if player.color == 'green':
                pygame.draw.rect(screen, 'GREEN', (self.pos_x + 13, self.pos_y + 55, 15, 15))
            if player.color == 'purple':
                pygame.draw.rect(screen, 'PURPLE', (self.pos_x + 80, self.pos_y + 88, 15, 15))
