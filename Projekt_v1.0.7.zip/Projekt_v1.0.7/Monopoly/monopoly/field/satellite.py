import pygame
from .field import Field


class Satellite(Field):
    """
    representation of the 'satellite' field
    """
    def __init__(self, index, pos_x, pos_y, image, att, screen):
        super().__init__(index, 'satellite', pos_x, pos_y, image)
        self.hitbox = pygame.Rect(self.pos_x, self.pos_y, self.image.get_width(), self.image.get_height())
        self.owner = None
        self.att = att
        self.screen = screen

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        # TODO napis
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            # ----------TŁO KARTY-----------------------
            pygame.draw.rect(self.screen, 'WHITE', (250, 550, 176, 286), 0, 10, -10, -10, -10,
                             -10)  # tło karty
            pygame.draw.rect(self.screen, (0, 0, 0), (253, 553, 170, 280), 2, 10, -10, -10, -10,
                             -10)  # ramka
            pygame.draw.rect(self.screen, (0, 0, 0), (256, 556, 164, 54), 2, 10, -10, -10, -10,
                             -10)  # ramka koloru
            text5 = pygame.font.Font.render(pygame.font.SysFont(None, 30), f"{self.att[14]}", True, (0, 0, 0))
            self.screen.blit(text5, (263, 574))
            # ------------------------------------------
            font = pygame.font.SysFont(None, 20)
            pos_x_left = 260
            pos_x_right = 385
            pos_y = 617

            for att in [2, 3, 4, 5]:
                if att == 2:
                    text_surface_left = font.render(f"Czynsz: ", True,
                                                    (0, 0, 0))
                    self.screen.blit(text_surface_left, (pos_x_left, pos_y))
                elif att == 3:
                    text_surface_left = font.render(f"Przy 2 stacjach: ", True,
                                                    (0, 0, 0))
                    self.screen.blit(text_surface_left, (pos_x_left, pos_y))
                elif att == 4:
                    text_surface_left = font.render(f"Przy 3 stacjach: ", True,
                                                    (0, 0, 0))
                    self.screen.blit(text_surface_left, (pos_x_left, pos_y))
                elif att == 5:
                    text_surface_left = font.render(f"Przy 4 stacjach: ", True,
                                                    (0, 0, 0))
                    self.screen.blit(text_surface_left, (pos_x_left, pos_y))

                text_surface_right = font.render(f"${self.att[att]}", True, (0, 0, 0))
                self.screen.blit(text_surface_right, (pos_x_right, pos_y))

                pos_y += 50



    def player_on_field_action(self, player):
        # TODO opcja kupienia
        pass
