import pygame


class Field:
    def __init__(self, index, name, pos_x, pos_y, image):
        """
        constructor
        """
        self.index = index
        self.name = name
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.image = image
        self.standing_players = []
        self.screen = None

    def field_clicked(self):
        raise Exception("field_clicked() not implemented")

    def field_mouse_on(self):
        raise Exception("field_mouse_on() not implemented")

    def player_on_field_action(self, player):
        raise Exception("player_on_field_action() not implemented")

    def draw(self, screen):
        self.screen = screen
        screen.blit(self.image, (self.pos_x, self.pos_y))

        for color in self.standing_players:
            self._draw_player(color, screen)

    def add_player(self, player):
        if player not in self.standing_players:
            self.standing_players.append(player)

    def remove_player(self, player):
        if player in self.standing_players:
            self.standing_players.remove(player)

    def _draw_player(self, player, screen):
        if player.color == 'red':
            pygame.draw.rect(screen, 'RED', (self.pos_x + 18, self.pos_y + 40, 15, 15))
        if player.color == 'blue':
            pygame.draw.rect(screen, 'BLUE', (self.pos_x + 38, self.pos_y + 40, 15, 15))
        if player.color == 'green':
            pygame.draw.rect(screen, 'GREEN', (self.pos_x + 18, self.pos_y + 60, 15, 15))
        if player.color == 'purple':
            pygame.draw.rect(screen, 'PURPLE', (self.pos_x + 38, self.pos_y + 60, 15, 15))
