import pygame.time
from .player import Player
from ..sound import *


class AiPlayer(Player):
    def __init__(self, color, game):
        super().__init__(color, game)
        self.dice = game.dice
        self.game_over = game.game_over

    def player_action(self):
        if self.bankrupt:
            return True
        if self.is_in_prison:
            self.prison_counter -= 1
            return True
        if self.game_over:
            return True

        self.message.add_message(f"@ tura gracza {self.color}")
        self.message.show_message(self.screen)
        pygame.display.update()

        self.dice.double_roll()

        pygame.time.delay(1000)
        self.message.add_message(f"gracz {self.color} wyrzucił {self.dice.get_turn_value()}")
        self.message.show_message(self.screen)
        self.dice.draw(self.screen)
        pygame.display.update()

        pygame.time.delay(1000)
        self.move(self.dice.get_turn_value())
        #self.move(1)
        pygame.display.update()


        self.select_action(self.evaluate())


        return True

    def evaluate(self):
        w = [0] * 9  # - zbiór wartości akcji

        standing_field = self.board.get_field(self.position)
        color_fields_count = 0
        color_field_else_owner = 0
        field_value = 0
        houses_on_others_fields = False
        monopol = False

        if hasattr(standing_field, 'home_counter'):
            for field in self.board.get_all_color_fields(standing_field.name):
                if field.owner == self:
                    color_fields_count += 1
                if field.owner is not None and field.owner != self:
                    color_field_else_owner += 1

            if standing_field.att[14] == 'red':
                field_value = 100
            if standing_field.att[14] == 'yellow':
                field_value = 40
            if standing_field.att[14] == 'green':
                field_value = 20
            if standing_field.att[14] == 'darkblue':
                field_value = 20
            if standing_field.att[14] == 'orange':
                field_value = 100
            if standing_field.att[14] == 'pink':
                field_value = 40
            if standing_field.att[14] == 'lightblue':
                field_value = 20
            if standing_field.att[14] == 'brown':
                field_value = 20


        # === kupowanie pola w(0) ===
        if not hasattr(standing_field, 'owner'):
            print('no owner att')
            w[0] = 0
        elif standing_field.owner is not None:
            print('is not none ')
            w[0] = 0
        elif self.money <= standing_field.att[1]:
            print('money xx')
            w[0] = 0
        else:
            if color_fields_count == 0:
                w[0] += 10
                if color_field_else_owner == 0:
                    w[0] -= 5
                elif color_field_else_owner == 1:
                    w[0] -= 10
                else:
                    w[0] -= 15
            elif color_fields_count == 1:
                w[0] += 20
                if color_field_else_owner == 0:
                    w[0] -= 5
                elif color_field_else_owner == 1:
                    w[0] -= 10
            elif color_fields_count == 2:
                w[0] += 30

            if standing_field.att[1] < self.money < 1.5 * standing_field.att[1]:
                w[0] -= 20
                w[0] += field_value / 3
                print('aaa')
            elif 1.5 * standing_field.att[1] <= self.money < 4 * standing_field.att[1]:
                w[0] += 10
                w[0] += field_value / 2.5
                print('bbb')
            else:
                w[0] += 20
                w[0] += field_value / 2
                print('ccc')
        print(w[0])



        if monopol:
            if standing_field.att[9] < self.money <= 3 * standing_field.att[9]:
                w[1] = 0
                w[1] += standing_field.stt[1] / 3
                if houses_on_others_fields:
                    w[1] += 5
            elif 3 * standing_field.att[9] < self.money <= 4 * standing_field.att[9]:
                w[1] += 15
                w[1] += field_value / 2.5
                if houses_on_others_fields:
                    w[1] += 10
            elif 4 * standing_field.att[9] < self.money <= 6 * standing_field.att[9]:
                w[1] += 30
                w[1] += field_value / 2
                if houses_on_others_fields:
                    w[1] += 20
            elif 6 * standing_field.att[9] < self.money:
                w[1] += 50
                w[1] += field_value / 1.5
                if houses_on_others_fields:
                    w[1] += 30
        else:
            w[1] = 0



        if monopol:
            if hasattr(standing_field, 'home_counter'):
                if houses_on_others_fields and standing_field.home_counter == 4:
                    if standing_field.att[10] <= self.money <= 3 * standing_field.att[10]:
                        w[2] += field_value / 3
                    elif 3 * standing_field.att[10] < self.money <= 4 * standing_field.att[10]:
                        w[2] += (field_value / 2.5) + 10
                    elif 4 * standing_field.att[10] < self.money <= 6 * standing_field.att[10]:
                        w[2] += (field_value / 2) + 20
                    elif 6 * standing_field.att[10] < self.money:
                        w[2] += (field_value / 1.5) + 30
            else:
                w[2] = 0
        else:
            w[2] = 0


        return w

    def select_action(self, w):
        max_action_value = max(w)
        print(f'max value {max_action_value}')
        while max_action_value >= 20:
            print(f'wykonanie akcji {w.index(max_action_value)} o wartosci akcji: {max_action_value}')
            self.make_action(w.index(max_action_value))

            w = self.evaluate()
            max_action_value = max(w)


    def make_action(self, index):
        standing_field = self.board.get_field(self.position)

        if index == 0:
            # akcja 0 kupowanie pola
            self.money -= standing_field.att[1]
            standing_field.owner = self
            sound.BUY_SOUND.play(0)
            self.message.add_message(f'gracz {self.color} kupuje pole {standing_field.att[14]} (- ${standing_field.att[1]})')

        if index == 1:
            # akcja 1 kupowanie domku
            self.money -= standing_field.att[9]
            standing_field.home_counter += 1
            self.message.add_message(f'gracz {self.color} kupuje domek (- ${standing_field.att[9]})')

        if index == 2:
            # akcja 2 kupowanie hotelu
            self.money -= standing_field.att[10]
            standing_field.home_counter += 1
            self.message.add_message(f'gracz {self.color} kupuje hotel (- ${standing_field.att[10]})')

        if index == 3:
            # akcja 3 sprzedawanie domku
            self.money += int(standing_field.att[9]/2)
            standing_field.home_counter -= 1
            self.message.add_message(f'gracz {self.color} sprzedaje domek (+ ${int(standing_field.att[9]/2)})')

        if index == 4:
            # akcja 4 sprzedawanie hotelu
            self.money += int(standing_field.att[10]/2)
            standing_field.home_counter -= 1
            self.message.add_message(f'gracz {self.color} sprzedaje hotel (+ ${int(standing_field.att[10]/2)})')
