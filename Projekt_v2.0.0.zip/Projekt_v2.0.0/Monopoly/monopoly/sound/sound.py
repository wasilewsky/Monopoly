import pygame, os

pygame.mixer.init()

path = os.path.join(os.pardir, 'Monopoly/sound')

BUTTON_SOUND1 = pygame.mixer.Sound(os.path.join(path, 'click_sound.wav'))
HITBOX_SOUND1 = pygame.mixer.Sound(os.path.join(path, 'choose_sound.wav'))

BACKGROUND_SOUND1 = pygame.mixer.Sound(os.path.join(path, 'background1.wav'))
BACKGROUND_SOUND2 = pygame.mixer.Sound(os.path.join(path, 'background2.mp3'))

END_SOUND = pygame.mixer.Sound(os.path.join(path, 'przegrana.wav'))
BUY_SOUND = pygame.mixer.Sound(os.path.join(path, 'kup.wav'))

ROLL_SOUND = pygame.mixer.Sound(os.path.join(path, 'rzut.mp3'))
MOVE_SOUND = pygame.mixer.Sound(os.path.join(path, 'wolny_dzwiek1.wav'))

HITBOX_SOUND1.set_volume(0.1)
BUTTON_SOUND1.set_volume(0.1)

BACKGROUND_SOUND1.set_volume(0.02)
BACKGROUND_SOUND2.set_volume(0.02)

END_SOUND.set_volume(0.2)
BUY_SOUND.set_volume(0.2)
ROLL_SOUND.set_volume(0.2)
MOVE_SOUND.set_volume(0.2)

