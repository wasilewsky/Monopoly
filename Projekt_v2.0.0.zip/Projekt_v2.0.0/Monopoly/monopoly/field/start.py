import pygame
from .field import Field


class Start(Field):
    """
    representation of the 'START' field
    """
    def __init__(self, index, pos_x, pos_y, image):
        super().__init__(index, 'start', pos_x, pos_y, image)

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        pass

    def player_on_field_action(self, player):
        """
        money for moving through start is implement elswere
        """
        pass

    def _draw_player(self, player, screen):
        if player.color == 'red':
            if not player.bankrupt:
                pygame.draw.rect(screen, '#ff0000', (self.pos_x + 40, self.pos_y + 40, 15, 15))
        if player.color == 'blue':
            if not player.bankrupt:
                pygame.draw.rect(screen, '#0000ff', (self.pos_x + 60, self.pos_y + 40, 15, 15))
        if player.color == 'green':
            if not player.bankrupt:
                pygame.draw.rect(screen, '#00ff00', (self.pos_x + 40, self.pos_y + 60, 15, 15))
        if player.color == 'purple':
            if not player.bankrupt:
                pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 60, self.pos_y + 60, 15, 15))
