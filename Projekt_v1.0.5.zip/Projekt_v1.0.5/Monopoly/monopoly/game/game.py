from ..board import *
from ..player import *
from ..message import *
from ..button import *
from ..image import *
from ..info_table import *


class Game:
    def __init__(self, screen, selected_color):
        self.board = Board()
        self.screen = screen
        self.selected_color = selected_color
        self.players = []
        self.message = Message()
        self._make_players()
        self.current_player_index = 3  # to do zmiany by było losowanie kostką
        self.switch_player()  # to do wywalenia - jedynie test wypisywania

        self.info_table = InfoTable(screen, self.players)

        self.rzut_button = Button(1000, 750, image.RZUT_BTN, True)
        self.kup_button = Button(1220, 750, image.KUPPOLE_BTN, True)
        self.kupDom_button = Button(1440, 750, image.KUPDOM_BTN, True)
        self.sprzedajDom_button = Button(1660, 750, image.SPRZEDAJDOM_BTN, True)

        self.zastaw_button = Button(1000, 870, image.ZASTAW_BTN, True)
        self.wykup_button = Button(1220, 870, image.WYKUP_BTN, True)
        self.handel_button = Button(1440, 870, image.HANDEL_BTN, True)
        self.dalej_button = Button(1660, 870, image.DALEJ_BTN, True)
        self.dice_rolled = False

    def draw(self):
        if self.current_player_index == 0 and not self.dice_rolled:
            self.rzut_button.set_visible(True)
            self.kup_button.set_visible(False)
            self.kupDom_button.set_visible(False)
            self.sprzedajDom_button.set_visible(False)
            self.zastaw_button.set_visible(False)
            self.wykup_button.set_visible(False)
            self.handel_button.set_visible(False)
            self.dalej_button.set_visible(False)


        self.board.draw(self.screen)
        self.message.show_message(self.screen)

        self.info_table.draw()

        self.rzut_button.draw(screen)
        self.kup_button.draw(screen)
        self.kupDom_button.draw(screen)
        self.sprzedajDom_button.draw(screen)

        self.zastaw_button.draw(screen)
        self.wykup_button.draw(screen)
        self.handel_button.draw(screen)
        self.dalej_button.draw(screen)

        if self.dalej_button.click():
            self.dalej_button.set_visible(False)
            self.switch_player()
            return

        if self.current_player_index != 0:
            self.dice_rolled = False
            if self.players[self.current_player_index].player_action():
                self.switch_player()

        if self.rzut_button.click():
            self.dice_rolled = True
            self.rzut_button.set_visible(False)
            self.dalej_button.set_visible(True)
            self.players[self.current_player_index].move(30)
            self.board.draw(self.screen)



    def _make_players(self):
        main_player = MainPlayer(self.selected_color, self.board, self.message, self.screen)
        self.players.append(main_player)

        colors = ['red', 'blue', 'green', 'purple']
        colors.remove(self.selected_color)

        for color in colors:
            ai_player = AiPlayer(color, self.board, self.message, self.screen)
            self.players.append(ai_player)

    def switch_player(self):
        self.current_player_index = (self.current_player_index + 1) % len(self.players)
        if self.current_player_index == 0:
            self.message.add_message('@ twoja kolej:')
