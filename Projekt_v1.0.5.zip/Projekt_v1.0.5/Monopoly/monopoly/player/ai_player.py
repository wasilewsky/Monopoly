import pygame.time

from .player import Player


class AiPlayer(Player):
    def __init__(self, color, board, message, screen):
        super().__init__(color, board, message, screen)

    def player_action(self):
        self.message.add_message(f"gracz {self.color} wykonuje ruch")
        self.message.show_message(self.screen)
        pygame.display.update()
        pygame.time.delay(1000)
        self.move(1)
        pygame.display.update()
        return True
