from .player import Player


class MainPlayer(Player):
    def __init__(self, color, board, message, screen):
        super().__init__(color, board, message, screen)

    def player_action(self):
        """
        main player actions are handled elsewhere
        """
        pass
