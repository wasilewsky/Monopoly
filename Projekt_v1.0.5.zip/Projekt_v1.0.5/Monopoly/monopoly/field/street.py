import pygame
from .field import Field
from ..settings import FIELDS_ATT


class Street(Field):
    """
    representation of the 'street' field
    """
    def __init__(self, index, pos_x, pos_y, image, color, att, screen):
        super().__init__(index, f'{color}', pos_x, pos_y, image)
        self.hitbox = pygame.Rect(self.pos_x, self.pos_y, self.image.get_width(), self.image.get_height())
        self.owner = None
        self.att = att
        self.screen = screen

    def field_clicked(self):
        # TODO opcje do wykonania z polem
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            if pygame.mouse.get_pressed()[0]:
                czcionka = pygame.font.SysFont("georgia", 20)
                text = "cena:" + str(self.att[1])
                text_render = czcionka.render(text, 1, (250, 250, 250))
                self.screen.blit(text_render, (200, 630))

    def field_mouse_on(self):
        # TODO wyświetlanie informacji dokończyć
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            # czcionka = pygame.font.SysFont("georgia", 20)
            # text = "nazwa:" + self.att[14]
            # text_render = czcionka.render(text, 1, (250, 250, 250))
            # self.screen.blit(text_render, (200, 600))

            # ----------TŁO KARTY-----------------------
            pygame.draw.rect(self.screen, 'WHITE', (250, 550, 176, 286), 0, 10, -10, -10, -10,
                                     -10)  # tło karty
            pygame.draw.rect(self.screen, self.att[13], (256, 556, 164, 54), 0, 10, -10, -10, -10,
                                     -10)  # tło kolor
            pygame.draw.rect(self.screen, (0, 0, 0), (253, 553, 170, 280), 2, 10, -10, -10, -10,
                                     -10)  # ramka
            pygame.draw.rect(self.screen, (0, 0, 0), (256, 556, 164, 54), 2, 10, -10, -10, -10,
                                     -10)  # ramka koloru
            text5 = pygame.font.Font.render(pygame.font.SysFont(None, 30), f"{self.att[14]}", True, (0, 0, 0))
            self.screen.blit(text5, (263, 574))
            # ------------------------------------------

            # ----------DANE KARTY----------------------
            font = pygame.font.SysFont(None, 20)
            pos_x_left = 260
            pos_x_right = 385
            pos_y = 617
            for att in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]:
                text_surface_left = font.render(f"{FIELDS_ATT[0][att].capitalize().replace('_', ' ')}:", True, (0, 0, 0))
                self.screen.blit(text_surface_left, (pos_x_left, pos_y))

                text_surface_right = font.render(f"${self.att[att]}", True, (0, 0, 0))
                self.screen.blit(text_surface_right, (pos_x_right, pos_y))

                pos_y += 22
            # ------------------------------------------

    def player_on_field_action(self, player):
        player.money -= self.att[1]
