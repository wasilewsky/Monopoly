from .field import Field


class Chance(Field):
    """
    representation of the 'chance' field
    """
    def __init__(self, index, pos_x, pos_y, image):
        super().__init__(index, 'chance', pos_x, pos_y, image)

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        pass

    def player_on_field_action(self, player):
        # TODO gracz wyciąga kartę
        pass
