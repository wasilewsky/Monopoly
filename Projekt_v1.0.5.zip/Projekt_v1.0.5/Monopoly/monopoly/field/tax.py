from .field import Field
import pygame


class Tax(Field):
    """
    representation of the 'tax' field
    """
    def __init__(self, index, pos_x, pos_y, image, tax_amount=100):
        super().__init__(index, 'tax', pos_x, pos_y, image)
        self.tax_amount = tax_amount

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        pass

    def player_on_field_action(self, player):
        # TODO gracz płaci tax_amount
        pass

    def _draw_player(self, player, screen):
        if player.color == 'red':
            pygame.draw.rect(screen, 'RED', (self.pos_x + 10, self.pos_y + 10, 15, 15))
        if player.color == 'green':
            pygame.draw.rect(screen, 'GREEN', (self.pos_x + 30, self.pos_y + 10, 15, 15))
        if player.color == 'blue':
            pygame.draw.rect(screen, 'BLUE', (self.pos_x + 10, self.pos_y + 30, 15, 15))
        if player.color == 'purple':
            pygame.draw.rect(screen, 'PURPLE', (self.pos_x + 30, self.pos_y + 30, 15, 15))
