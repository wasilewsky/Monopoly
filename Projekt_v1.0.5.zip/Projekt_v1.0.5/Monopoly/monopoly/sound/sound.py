import pygame, os

pygame.mixer.init()

path = os.path.join(os.pardir, 'Monopoly/sound')

BUTTON_SOUND1 = pygame.mixer.Sound(os.path.join(path, 'click_sound.wav'))
HITBOX_SOUND1 = pygame.mixer.Sound(os.path.join(path, 'choose_sound.wav'))

HITBOX_SOUND1.set_volume(0.1)
BUTTON_SOUND1.set_volume(0.1)
