import pygame
from .field import Field
from ..sound import *
from ..settings import chance_cards
import random


class Chance(Field):
    """
    representation of the 'chance' field
    """
    def __init__(self, index, pos_x, pos_y, image):
        super().__init__(index, 'chance', pos_x, pos_y, image)

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        pass

    def player_on_field_action(self, player):
        chance_card = random.choice(chance_cards)
        #print(chance_card)
        chance_card = chance_cards[1]
        card_number, card_description = chance_card
        #print(f"Player {player.color} drew card {card_number}: {card_description}")

        pygame.draw.rect(self.screen, 'WHITE', (430, 550, 406, 176), 0, 10, -10, -10, -10,
                         -10)  # tło karty
        pygame.draw.rect(self.screen, (0, 0, 0), (433, 553, 400, 170), 2, 10, -10, -10, -10,
                         -10)  # ramka
        text5 = pygame.font.Font.render(pygame.font.SysFont(None, 30), f"KARTA SZANSY", True, (0, 0, 0))
        self.screen.blit(text5, (550, 574))
        text5 = pygame.font.Font.render(pygame.font.SysFont(None, 18), f"{card_description}", True, (0, 0, 0))
        self.screen.blit(text5, (443, 635))

        pygame.display.update()
        pygame.time.delay(2000)

        if card_number == 1:
            player.move(41 - player.position)
        elif card_number == 2:
            step = 12 - player.position
            if step < 0:
                step = 40 + step
            player.move(step)
        elif card_number == 3:
            while player.position != 6 and player.position != 16 and player.position != 26 and player.position != 36:
                player.move(1)

        elif card_number == 4:
            while player.position != 25:
                player.move(1)
                pygame.time.delay(200)

        elif card_number == 5:  # TU MA BYC KARTA WYJSCIA Z WIEZIENIA !!!!!
            pass
        elif card_number == 6:
            while player.position != 6:
                player.move(1)

        elif card_number == 7:
            while player.position != 13 and player.position != 29:
                player.move(1)

        elif card_number == 8:
            player.move(0)
            player.money -= 200
            # self.players[1].money += 50
            # self.players[2].money += 50
            # self.players[3].money += 50
            # self.players[0].money += 50

        elif card_number == 9:
            for x in range(3):
                player.move(-1)

        elif card_number == 10:
            player.move(0)
            player.money += 50

        elif card_number == 11:  # ZA KAZDY DOM $25 A ZA HOTEL $100
            pass
        elif card_number == 12:  # IDZ DO WIEZIENIA
            pass
        elif card_number == 13:
            while player.position != 40:
                player.move(1)

        elif card_number == 14:
            player.move(0)
            player.money -= 15

        elif card_number == 15:
            player.move(0)
            player.money += 150

        elif card_number == 16:
            while player.position != 6 and player.position != 16 and player.position != 26 and player.position != 36:
                player.move(1)

        pygame.time.delay(1000)
        # return f'gracz {player.color} dostaje $100'

    def _draw_player(self, player, screen):
        if self.index == 8:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

        if self.index == 23:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

        if self.index == 37:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 40, self.pos_y + 18, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 60, self.pos_y + 18, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 40, self.pos_y + 38, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 60, self.pos_y + 38, 15, 15))
