import pygame
from .field import Field


class Chest(Field):
    """
    representation of the 'chest' field
    """
    def __init__(self, index, pos_x, pos_y, image):
        super().__init__(index, 'chest', pos_x, pos_y, image)

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        pass

    def player_on_field_action(self, player):
        pass

    def _draw_player(self, player, screen):
        if self.index == 3:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

        if self.index == 18:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 30, self.pos_y + 18, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 50, self.pos_y + 18, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 30, self.pos_y + 38, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 50, self.pos_y + 38, 15, 15))

        if self.index == 34:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 40, self.pos_y + 18, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 60, self.pos_y + 18, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 40, self.pos_y + 38, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 60, self.pos_y + 38, 15, 15))
