import pygame
from .field import Field
from ..settings import FIELDS_ATT
from ..image import *
from ..sound import *


class Street(Field):
    """
    representation of the 'street' field
    """
    def __init__(self, index, pos_x, pos_y, image, color, att, screen):
        super().__init__(index, f'{color}', pos_x, pos_y, image)
        self.hitbox = pygame.Rect(self.pos_x, self.pos_y, self.image.get_width(), self.image.get_height())
        self.owner = None
        self.att = att
        self.screen = screen
        self.clicked = False
        self.mortgage = False
        self.home_counter = 0  # 1-4 homes; 5-8 hotels

    def field_clicked(self):
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            if pygame.mouse.get_pressed()[0]:
                if not self.clicked:
                    self.clicked = True
                else:
                    self.clicked = False
                pygame.time.delay(200)
                return self

                #czcionka = pygame.font.SysFont("georgia", 20)
                #text = "cena:" + str(self.att[1])
                #text_render = czcionka.render(text, 1, (250, 250, 250))
                #self.screen.blit(text_render, (200, 630))

    def field_mouse_on(self):
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            # czcionka = pygame.font.SysFont("georgia", 20)
            # text = "nazwa:" + self.att[14]
            # text_render = czcionka.render(text, 1, (250, 250, 250))
            # self.screen.blit(text_render, (200, 600))

            # ----------TŁO KARTY-----------------------
            pygame.draw.rect(self.screen, 'WHITE', (250, 550, 176, 286), 0, 10, -10, -10, -10,
                                     -10)  # tło karty
            pygame.draw.rect(self.screen, self.att[13], (256, 556, 164, 54), 0, 10, -10, -10, -10,
                                     -10)  # tło kolor
            pygame.draw.rect(self.screen, (0, 0, 0), (253, 553, 170, 280), 2, 10, -10, -10, -10,
                                     -10)  # ramka
            pygame.draw.rect(self.screen, (0, 0, 0), (256, 556, 164, 54), 2, 10, -10, -10, -10,
                                     -10)  # ramka koloru
            text5 = pygame.font.Font.render(pygame.font.SysFont(None, 30), f"{self.att[14]}", True, (0, 0, 0))
            self.screen.blit(text5, (263, 574))
            # ------------------------------------------

            # ----------DANE KARTY----------------------
            font = pygame.font.SysFont(None, 20)
            pos_x_left = 260
            pos_x_right = 385
            pos_y = 617
            for att in [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]:
                text_surface_left = font.render(f"{FIELDS_ATT[0][att].capitalize().replace('_', ' ')}:", True, (0, 0, 0))
                self.screen.blit(text_surface_left, (pos_x_left, pos_y))

                text_surface_right = font.render(f"${self.att[att]}", True, (0, 0, 0))
                self.screen.blit(text_surface_right, (pos_x_right, pos_y))

                pos_y += 22
            # ------------------------------------------

    def player_on_field_action(self, player):
        tax = 0
        if self.owner is not None and self.owner != player and not self.mortgage and not self.owner.bankrupt:
            if self.home_counter < 5:
                tax = self.att[self.home_counter+3]
            if self.home_counter > 4:
                tax = (self.home_counter-4)*self.att[8]
            if player.money < tax:
                player.bankrupt = True
                return f'gracz {player.color} bankrutuje'
            else:
                player.money -= tax
                self.owner.money += tax
                sound.BUY_SOUND.play(0)
                return f'{player.color} płaci graczowi {self.owner.color} ${tax}'


    def draw(self, screen):
        self.screen = screen
        screen.blit(self.image, (self.pos_x, self.pos_y))

        for color in self.standing_players:
            self._draw_player(color, screen)

        if self.owner is not None:
            self._draw_owner(screen)

        if self.mortgage:
            self._draw_mortgage(screen)

        self._draw_main_border(screen)

        if self.home_counter > 0:
            self._draw_homes(screen)

        if self.clicked:
            self._draw_border(screen)

    def _draw_border(self, screen):
        # up
        pygame.draw.rect(screen, 'BLACK', (self.pos_x, self.pos_y, self.image.get_width(), 5))
        # left
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x, self.pos_y, 5, self.image.get_height()))
        # down
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x, self.pos_y + self.image.get_height() - 5, self.image.get_width(), 5))
        # right
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x + self.image.get_width() - 5, self.pos_y, 5, self.image.get_height()))

    def _draw_mortgage(self, screen):
        color = 'gray'
        down = (2, 4, 7, 9, 10)
        left = (12, 14, 15, 17, 19, 20)
        up = (22, 24, 25, 27, 28, 30)
        right = (32, 33, 35, 38, 40)

        if self.index in down:
            pygame.draw.rect(screen, color, (self.pos_x, self.pos_y + 117 - 30, 70, 15))
        if self.index in left:
            pygame.draw.rect(screen, color, (self.pos_x + 15, self.pos_y, 15, 70))
        if self.index in up:
            pygame.draw.rect(screen, color, (self.pos_x, self.pos_y + 15, 70, 15))
        if self.index in right:
            pygame.draw.rect(screen, color, (self.pos_x + 117 - 30, self.pos_y + 1, 15, 70))

    def _draw_homes(self, screen):
        counter = self.home_counter
        color = image.DOM_OBR
        if self.home_counter > 4:
            counter = self.home_counter - 4
            color = image.HOTEL_OBR
        down = (2, 4, 7, 9, 10)
        left = (12, 14, 15, 17, 19, 20)
        up = (22, 24, 25, 27, 28, 30)
        right = (32, 33, 35, 38, 40)

        if self.index in down:
            for x in range(counter):
                screen.blit(color, (self.pos_x + 2 + x*1.25 + x*16, self.pos_y + 5))
                #pygame.draw.rect(screen, color, (self.pos_x + 2 + x*1.25 + x*16, self.pos_y + 5, 16, 16))
        if self.index in left:
            for x in range(counter):
                screen.blit(color, (self.pos_x + 117 - 5 - 16, self.pos_y + 2 + x*1.25 + x*16))
                #pygame.draw.rect(screen, color, (self.pos_x + 117 - 5 - 16, self.pos_y + 2 + x*1.25 + x*16, 16, 16))
        if self.index in up:
            for x in range(counter):
                screen.blit(color, (self.pos_x + 2 + x*1.25 + x*16, self.pos_y + 117 - 5 - 16))
                #pygame.draw.rect(screen, color, (self.pos_x + 2 + x*1.25 + x*16, self.pos_y + 117 - 5 - 16, 16, 16))
        if self.index in right:
            for x in range(counter):
                screen.blit(color, (self.pos_x + 5, self.pos_y + 2 + x*1.25 + x*16))
                #pygame.draw.rect(screen, color, (self.pos_x + 5, self.pos_y + 2 + x*1.25 + x*16, 16, 16))

    def _draw_main_border(self, screen):
        # up
        pygame.draw.rect(screen, 'BLACK', (self.pos_x, self.pos_y, self.image.get_width(), 1))
        # left
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x, self.pos_y, 1, self.image.get_height()))
        # down
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x, self.pos_y + self.image.get_height() - 1, self.image.get_width(), 1))
        # right
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x + self.image.get_width() - 1, self.pos_y, 1, self.image.get_height()))

    def _draw_owner(self, screen):
        color = None
        down = (2, 4, 7, 9, 10)
        left = (12, 14, 15, 17, 19, 20)
        up = (22, 24, 25, 27, 28, 30)
        right = (32, 33, 35, 38, 40)

        if self.owner.color == 'red':
            color = 'RED'
        if self.owner.color == 'blue':
            color = 'BLUE'
        if self.owner.color == 'green':
            color = 'GREEN'
        if self.owner.color == 'purple':
            color = 'PURPLE'

        if self.index in down:
            pygame.draw.rect(screen, color, (self.pos_x + 1, self.pos_y + 117 - 15, 70, 15))
        if self.index in left:
            pygame.draw.rect(screen, color, (self.pos_x, self.pos_y + 1, 15, 70))
        if self.index in up:
            pygame.draw.rect(screen, color, (self.pos_x + 1, self.pos_y, 70, 15))
        if self.index in right:
            pygame.draw.rect(screen, color, (self.pos_x + 117 - 15, self.pos_y + 1, 15, 70))

    def _draw_player(self, player, screen):
        down = (2, 4, 7, 9, 10)
        left = (12, 14, 15, 17, 19, 20)
        up = (22, 24, 25, 27, 28, 30)
        right = (32, 33, 35, 38, 40)

        if self.index in down:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

        if self.index in left:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 30, self.pos_y + 18, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 50, self.pos_y + 18, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 30, self.pos_y + 38, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 50, self.pos_y + 38, 15, 15))

        if self.index in up:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

        if self.index in right:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 40, self.pos_y + 18, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 60, self.pos_y + 18, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 40, self.pos_y + 38, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 60, self.pos_y + 38, 15, 15))
