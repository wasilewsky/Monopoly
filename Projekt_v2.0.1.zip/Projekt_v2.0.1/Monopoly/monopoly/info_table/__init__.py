from .info_table import InfoTable
