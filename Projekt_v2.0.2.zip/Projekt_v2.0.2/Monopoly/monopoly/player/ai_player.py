import pygame.time
from .player import Player
from ..sound import *


class AiPlayer(Player):
    def __init__(self, color, game):
        super().__init__(color, game)
        self.dice = game.dice
        self.game_over = game.game_over

    def player_action(self):
        if self.prison_counter == 0:
            self.is_in_prison = False
        if self.bankrupt:
            return True
        if self.is_in_prison:
            self.message.add_message(f"@ tura gracza {self.color}")
            self.message.show_message(self.screen)
            pygame.display.update()
            pygame.time.delay(1000)
            self.message.add_message(f"@ gracz {self.color} odsiaduje w więzieniu. (zostało {self.prison_counter})")
            self.message.show_message(self.screen)
            pygame.display.update()
            pygame.time.delay(1000)
            self.prison_counter -= 1
            return True
        if self.game_over:
            return True

        self.message.add_message(f"@ tura gracza {self.color}")
        self.message.show_message(self.screen)
        pygame.display.update()

        self.dice.double_roll()

        pygame.time.delay(1000)
        self.message.add_message(f"gracz {self.color} wyrzucił {self.dice.get_turn_value()}")
        self.message.show_message(self.screen)
        self.dice.draw(self.screen)
        pygame.display.update()

        pygame.time.delay(1000)
        #self.move(self.dice.get_turn_value())
        self.move(1)
        pygame.display.update()


        self.select_action(self.evaluate())


        return True

    def evaluate(self):
        w = [0] * 9  # - zbiór wartości akcji

        standing_field = self.board.get_field(self.position)
        color_fields_count = 0
        color_field_else_owner = 0
        field_value = 0
        houses_on_others_fields = False
        monopol = False
        same_owner_else_fields = False # czy ten sam gracz jest właścicielem wszystkich pól poza tym co stoimy
        else_owner = None # do sprawdzania same_owner_else_fields
        field_count = 0   # liczba pól danego typu/koloru co stoimy

        if hasattr(standing_field, 'home_counter'):
            for field in self.board.get_all_color_fields(standing_field.name):
                field_count += 1
                if field.owner == self:
                    color_fields_count += 1
                if field.owner is not None and field.owner != self:
                    if else_owner is None:
                        else_owner = field.owner
                    else:
                        if else_owner == field.owner:
                            same_owner_else_fields = True
                        else:
                            same_owner_else_fields = False
                    color_field_else_owner += 1

            if standing_field.att[14] == 'red':
                field_value = 100
            if standing_field.att[14] == 'yellow':
                field_value = 40
            if standing_field.att[14] == 'green':
                field_value = 20
            if standing_field.att[14] == 'darkblue':
                field_value = 20
            if standing_field.att[14] == 'orange':
                field_value = 100
            if standing_field.att[14] == 'pink':
                field_value = 40
            if standing_field.att[14] == 'lightblue':
                field_value = 20
            if standing_field.att[14] == 'brown':
                field_value = 20
        if hasattr(standing_field, 'owner') and not hasattr(standing_field, 'home_counter'):
            if standing_field.name == 'satellite':
                field_count += 1
                for field in self.board.fields:
                    if field.name == 'satellite':
                        field_count += 1
                        if field.owner == self:
                            color_fields_count += 1
                        if field.owner is not None and field.owner != self:
                            if else_owner is None:
                                else_owner = field.owner
                            else:
                                if else_owner == field.owner:
                                    same_owner_else_fields = True
                                else:
                                    same_owner_else_fields = False
                            color_field_else_owner += 1

                field_value = 10
            if standing_field.name == 'powerstation':
                for field in self.board.fields:
                    field_count += 1
                    if field.name == 'powerstation':
                        field_count += 1
                        if field.owner == self:
                            color_fields_count += 1
                        if field.owner is not None and field.owner != self:
                            if else_owner is None:
                                else_owner = field.owner
                            else:
                                if else_owner == field.owner:
                                    same_owner_else_fields = True
                                else:
                                    same_owner_else_fields = False
                            color_field_else_owner += 1

                field_value = 15

        field_amount = 0
        for field in self.board.fields:
            if hasattr(field, 'owner'):
                if field.owner == self:
                    field_amount += 1


        # === kupowanie pola w(0) ===

        if not hasattr(standing_field, 'owner'):
            w[0] = 0
        elif standing_field.owner is not None:
            w[0] = 0
        elif self.money <= standing_field.att[1]:
            w[0] = 0
        else:
            # heat map impact
            w[0] = field_value

            # jeśli gracz ma mało pol
            if field_amount < 3:
                w[0] += 50


            # myself field count impact
            if color_fields_count == 0:
                w[0] -= 20
            elif color_fields_count == 1:
                w[0] += 30
            elif color_fields_count == 2:
                w[0] += 50

            # else player field count impact

            if color_field_else_owner == 0:
                w[0] += 10
            elif color_field_else_owner == 1:
                w[0] -= 30
            elif color_field_else_owner == 2:
                if same_owner_else_fields:
                    w[0] += 50
                else:
                    w[0] -= 50

            # money vs cost impact
            if standing_field.att[1] < self.money < 1.5 * standing_field.att[1]:
                w[0] -= 10
            elif 1.5 * standing_field.att[1] <= self.money < 2.5 * standing_field.att[1]:
                w[0] += 20
            elif 2.5 * standing_field.att[1] <= self.money < 4 * standing_field.att[1]:
                w[0] += 50
            else:
                w[0] += 70
        print(w[0])



        if monopol:
            if standing_field.att[9] < self.money <= 3 * standing_field.att[9]:
                w[1] = 0
                w[1] += standing_field.stt[1] / 3
                if houses_on_others_fields:
                    w[1] += 5
            elif 3 * standing_field.att[9] < self.money <= 4 * standing_field.att[9]:
                w[1] += 15
                w[1] += field_value / 2.5
                if houses_on_others_fields:
                    w[1] += 10
            elif 4 * standing_field.att[9] < self.money <= 6 * standing_field.att[9]:
                w[1] += 30
                w[1] += field_value / 2
                if houses_on_others_fields:
                    w[1] += 20
            elif 6 * standing_field.att[9] < self.money:
                w[1] += 50
                w[1] += field_value / 1.5
                if houses_on_others_fields:
                    w[1] += 30
        else:
            w[1] = 0



        if monopol:
            if hasattr(standing_field, 'home_counter'):
                if houses_on_others_fields and standing_field.home_counter == 4:
                    if standing_field.att[10] <= self.money <= 3 * standing_field.att[10]:
                        w[2] += field_value / 3
                    elif 3 * standing_field.att[10] < self.money <= 4 * standing_field.att[10]:
                        w[2] += (field_value / 2.5) + 10
                    elif 4 * standing_field.att[10] < self.money <= 6 * standing_field.att[10]:
                        w[2] += (field_value / 2) + 20
                    elif 6 * standing_field.att[10] < self.money:
                        w[2] += (field_value / 1.5) + 30
            else:
                w[2] = 0
        else:
            w[2] = 0


        return w

    def select_action(self, w):
        max_action_value = max(w)
        #print(f'max value {max_action_value}')
        while max_action_value >= 50:
            #print(f'wykonanie akcji {w.index(max_action_value)} o wartosci akcji: {max_action_value}')
            self.make_action(w.index(max_action_value))

            w = self.evaluate()
            max_action_value = max(w)


    def make_action(self, index):
        standing_field = self.board.get_field(self.position)

        if index == 0:
            # akcja 0 kupowanie pola
            self.money -= standing_field.att[1]
            standing_field.owner = self
            sound.BUY_SOUND.play(0)
            self.message.add_message(f'gracz {self.color} kupuje pole {standing_field.att[14]} (- ${standing_field.att[1]})')

        if index == 1:
            # akcja 1 kupowanie domku
            self.money -= standing_field.att[9]
            standing_field.home_counter += 1
            self.message.add_message(f'gracz {self.color} kupuje domek (- ${standing_field.att[9]})')

        if index == 2:
            # akcja 2 kupowanie hotelu
            self.money -= standing_field.att[10]
            standing_field.home_counter += 1
            self.message.add_message(f'gracz {self.color} kupuje hotel (- ${standing_field.att[10]})')

        if index == 3:
            # akcja 3 sprzedawanie domku
            self.money += int(standing_field.att[9]/2)
            standing_field.home_counter -= 1
            self.message.add_message(f'gracz {self.color} sprzedaje domek (+ ${int(standing_field.att[9]/2)})')

        if index == 4:
            # akcja 4 sprzedawanie hotelu
            self.money += int(standing_field.att[10]/2)
            standing_field.home_counter -= 1
            self.message.add_message(f'gracz {self.color} sprzedaje hotel (+ ${int(standing_field.att[10]/2)})')

        if index == 5:
            # akcja 5
            pass

    def trade(self, player, field, money):
        self.message.add_message(f'gracz {player.color} chce kupić pole {field.att[14]} za {money}')
        self.message.show_message(self.screen)
        pygame.display.update()
        pygame.time.delay(1000)

        '''
        kiedy przyjmuje
        money i field.att[1]
        ile pól w danym kolorze posiada
        self.money
        field value
        
        
        jesli ma bardzo malo kasy -> przyjmuje każdą propozycjię nawet jak monopol
        
        
        jeśli posiada 1 pole koloru i field value  < 100:
            mało kasy:
                field.att[1] + 10%
            srednio z kasą:
                field.att[1] + 20%
            dobrze z kasą:
                field.att[1] + 30%
                
        jeśli posiada 1 pole koloru i field value == 100:
            mało kasy:
                field.att[1] + 20%
            srednio z kasą:
                field.att[1] + 30%
            dobrze z kasą:
                spadaj
            
        jeśli ma 2 pola i field value  < 100:
            mało kasy:
                field.att[1] + 30%
            srednio z kasą:
                field.att[1] + 50%
            dobrze z kasą:
                spadaj
        
        jeśli ma 2 pola i field value  == 100:
            mało kasy:
                field.att[1] + 50%
            srednio z kasą:
                spadaj
            dobrze z kasą:
                spadaj
        
        jeśli ma monopol
            jeśli nie bardzo mało
                spadaj
        
        
        
        bardzo mało kasy - < 200
        mało kasy        - < 600
        srednio z kasą   - < 1000
        dobrze z kasą    - > 1000
        
        field.att[1] + 10%
        field.att[1] + 20%
        field.att[1] + 30%
        field.att[1] + 50%
        
        '''




        self.message.add_message(f'gracz {self.color} przyjmuje propozycję')
        self.message.show_message(self.screen)
        self.info_table.draw()
        pygame.display.update()
        pygame.time.delay(1000)

        self.message.add_message(f'gracz {self.color} odrzuca propozycję')
        self.message.show_message(self.screen)
        pygame.display.update()
        pygame.time.delay(1000)
