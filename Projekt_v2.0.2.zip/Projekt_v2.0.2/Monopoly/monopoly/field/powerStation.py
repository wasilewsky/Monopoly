from .field import Field
import pygame
from ..sound import *


class PowerStation(Field):
    """
    representation of the 'power station' field
    """
    def __init__(self, index, pos_x, pos_y, image, att, screen):
        super().__init__(index, 'powerstation', pos_x, pos_y, image)
        self.hitbox = pygame.Rect(self.pos_x, self.pos_y, self.image.get_width(), self.image.get_height())
        self.owner = None
        self.att = att
        self.screen = screen
        self.clicked = False
        self.mortgage = False

    def field_clicked(self):
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            if pygame.mouse.get_pressed()[0]:
                if not self.clicked:
                    self.clicked = True
                else:
                    self.clicked = False
                pygame.time.delay(200)
                return self

    def field_mouse_on(self):
        # TODO napis

         if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            # ----------TŁO KARTY-----------------------
            pygame.draw.rect(self.screen, 'WHITE', (250, 550, 176, 286), 0, 10, -10, -10, -10,
                             -10)  # tło karty
            pygame.draw.rect(self.screen, (0, 0, 0), (253, 553, 170, 280), 2, 10, -10, -10, -10,
                             -10)  # ramka
            pygame.draw.rect(self.screen, (0, 0, 0), (256, 556, 164, 54), 2, 10, -10, -10, -10,
                             -10)  # ramka koloru
            text5 = pygame.font.Font.render(pygame.font.SysFont(None, 30), f"{self.att[14]}", True, (0, 0, 0))
            text_rect = text5.get_rect(center=(250 + 176 // 2, 556 + 54 // 2))
            self.screen.blit(text5, text_rect)
            # ------------------------------------------
            pos_x_left = 255
            pos_y = 617

            text10 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"          Cena:  ${self.att[1]}",
                                             True, (0, 0, 0))
            self.screen.blit(text10, (pos_x_left + 10, pos_y))
            text11 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"        Przy posiadaniu", True,
                                             (0, 0, 0))
            self.screen.blit(text11, (pos_x_left, pos_y + 20))
            text12 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"   1 Zakładu, czynsz jest", True,
                                             (0, 0, 0))
            self.screen.blit(text12, (pos_x_left, pos_y + 40))
            text13 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"  czterokrotnością ilości",
                                             True,
                                             (0, 0, 0))
            self.screen.blit(text13, (pos_x_left, pos_y + 60))
            text14 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"     wyrzuconych oczek.",
                                             True,
                                             (0, 0, 0))
            self.screen.blit(text14, (pos_x_left, pos_y + 80))

            text11 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"        Przy posiadaniu", True,
                                             (0, 0, 0))
            self.screen.blit(text11, (pos_x_left, pos_y + 120))
            text12 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f" 2 Zakładów, czynsz jest", True,
                                             (0, 0, 0))
            self.screen.blit(text12, (pos_x_left, pos_y + 140))
            text13 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"    dziesięciokrotnością ",
                                             True,
                                             (0, 0, 0))
            self.screen.blit(text13, (pos_x_left, pos_y + 160))
            text14 = pygame.font.Font.render(pygame.font.SysFont(None, 20), f"ilości wyrzuconych oczek.",
                                             True,
                                             (0, 0, 0))
            self.screen.blit(text14, (pos_x_left, pos_y + 180))

    def draw(self, screen):
        self.screen = screen
        screen.blit(self.image, (self.pos_x, self.pos_y))

        for color in self.standing_players:
            self._draw_player(color, screen)

        if self.owner is not None:
            self._draw_owner(screen)

        if self.mortgage:
            self._draw_mortgage(screen)

        self._draw_main_border(screen)

        if self.clicked:
            self._draw_border(screen)

    def _draw_border(self, screen):
        # up
        pygame.draw.rect(screen, 'BLACK', (self.pos_x, self.pos_y, self.image.get_width(), 5))
        # left
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x, self.pos_y, 5, self.image.get_height()))
        # down
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x, self.pos_y + self.image.get_height() - 5, self.image.get_width(), 5))
        # right
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x + self.image.get_width() - 5, self.pos_y, 5, self.image.get_height()))

    def _draw_owner(self, screen):
        color = None

        if self.owner.color == 'red':
            color = 'RED'
        if self.owner.color == 'blue':
            color = 'BLUE'
        if self.owner.color == 'green':
            color = 'GREEN'
        if self.owner.color == 'purple':
            color = 'PURPLE'

        if self.index == 13:
            pygame.draw.rect(screen, color, (self.pos_x, self.pos_y + 1, 15, 70))
        if self.index == 29:
            pygame.draw.rect(screen, color, (self.pos_x + 1, self.pos_y, 70, 15))

    def _draw_mortgage(self, screen):
        color = 'gray'

        if self.index == 13:
            pygame.draw.rect(screen, color, (self.pos_x + 15, self.pos_y, 15, 70))
        if self.index == 29:
            pygame.draw.rect(screen, color, (self.pos_x, self.pos_y + 15, 70, 15))

    def _draw_player(self, player, screen):
        if self.index == 13:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 30, self.pos_y + 18, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 50, self.pos_y + 18, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 30, self.pos_y + 38, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 50, self.pos_y + 38, 15, 15))

        if self.index == 29:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

    def player_on_field_action(self, player):
        pstation_counter = 0
        tax = 0
        index = (13, 29)
        if self.owner is not None and self.owner != player and not self.mortgage and not self.owner.bankrupt:
            for field in self.owner.board.fields:
                if field.index in index and field.owner == self.owner and not field.mortgage:
                    pstation_counter += 1

            if pstation_counter == 1:
                tax = player.dice.get_turn_value() * 4
            if pstation_counter == 2:
                tax = player.dice.get_turn_value() * 10

            if player.money < tax:
                player.bankrupt = True
                return f'gracz {player.color} bankrutuje'
            else:
                player.money -= tax
                self.owner.money += tax
                sound.BUY_SOUND.play(0)
                return f'{player.color} płaci graczowi {self.owner.color} ${tax}'
