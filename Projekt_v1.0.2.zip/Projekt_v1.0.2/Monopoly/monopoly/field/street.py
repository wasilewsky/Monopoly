from .field import Field


class Street(Field):
    """
    representation of the 'street' field
    """
    def __init__(self, index, pos_x, pos_y, image, color):
        super().__init__(index, f'{color}', pos_x, pos_y, image)
        self.owner = None

    def field_clicked(self):
        # TODO opcje do wykonania z polem
        pass

    def field_mouse_on(self):
        # TODO wyświetlanie informacji
        pass

    def player_on_field_action(self):
        # TODO gracz płaci właścicielowi
        pass
