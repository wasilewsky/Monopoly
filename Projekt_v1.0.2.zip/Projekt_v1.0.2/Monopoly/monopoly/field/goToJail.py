from .field import Field


class GoToJail(Field):
    """
    representation of the 'go to jail' field
    """
    def __init__(self, index, pos_x, pos_y, image):
        super().__init__(index, 'gotojail', pos_x, pos_y, image)

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        pass

    def player_on_field_action(self):
        # TODO gracz idzie do więzienia
        pass
