from .field import Field


class Satellite(Field):
    """
    representation of the 'satellite' field
    """
    def __init__(self, index, pos_x, pos_y, image):
        super().__init__(index, 'satellite', pos_x, pos_y, image)

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        # TODO napis
        pass

    def player_on_field_action(self):
        # TODO opcja kupienia
        pass
