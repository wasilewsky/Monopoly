from .field import Field


class Tax(Field):
    """
    representation of the 'tax' field
    """
    def __init__(self, index, pos_x, pos_y, image, tax_amount=100):
        super().__init__(index, 'tax', pos_x, pos_y, image)
        self.tax_amount = tax_amount

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        pass

    def player_on_field_action(self):
        # TODO gracz płaci tax_amount
        pass
