from .field import Field


class PowerStation(Field):
    """
    representation of the 'power station' field
    """
    def __init__(self, index, pos_x, pos_y, image):
        super().__init__(index, 'powerstation', pos_x, pos_y, image)

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        # TODO napis
        pass

    def player_on_field_action(self):
        # TODO opcja kupienia
        pass
