from ..field import *
from ..image import *


class Board:
    def __init__(self):
        self.fields = []
        self._build_board()


    def _build_board(self):
        x, y = 10, 10
        #y += field.image.get_height()
        field_images = [image.POLEBROWN, image.POLECLOUD, image.POLECRYPTO, image.POLEDARKBLUE,
                        image.POLEELEKTROSLON, image.POLEGREEN, image.POLEINTERNET, image.POLEKASADOL, image.POLEKASAGORA,
                        image.POLEKASALEWO, image.POLEKASAPRAWO, image.POLELIGHTBLUE, image.POLEORANGE, image.POLEPINK,
                        image.POLESATELITAS, image.POLESATELITAW, image.POLESATELITAE,
                        image.POLESZANSADOL, image.POLESZANSALEWO, image.POLESZANSAPRAWO,
                        image.POLETAX, image.POLETAXDOL]
        # szansa

        # 21 parking
        field = Parking(21, x, y, image.POLEPARKING)
        x += field.image.get_width()
        self.fields.append(field)

        # 22 image.POLERED
        field = Parking(22, x, y, image.POLERED)
        x += field.image.get_width()
        self.fields.append(field)

        # 23 image.POLESZANSAGORA
        field = Parking(23, x, y, image.POLESZANSAGORA)
        x += field.image.get_width()
        self.fields.append(field)

        # 24 image.POLERED
        field = Parking(24, x, y, image.POLERED)
        x += field.image.get_width()
        self.fields.append(field)

        # 25 image.POLERED
        field = Parking(25, x, y, image.POLERED)
        x += field.image.get_width()
        self.fields.append(field)

        # 26 image.POLESATELITAN
        field = Parking(26, x, y, image.POLESATELITAN)
        x += field.image.get_width()
        self.fields.append(field)

        # 27 image.POLEYELLOW
        field = Parking(27, x, y, image.POLEYELLOW)
        x += field.image.get_width()
        self.fields.append(field)

        # 28 image.POLEYELLOW
        field = Parking(28, x, y, image.POLEYELLOW)
        x += field.image.get_width()
        self.fields.append(field)

        # 29 image.POLEELEKTROATOM
        field = Parking(29, x, y, image.POLEELEKTROATOM)
        x += field.image.get_width()
        self.fields.append(field)

        # 30 image.POLEYELLOW
        field = Parking(30, x, y, image.POLEYELLOW)
        x += field.image.get_width()
        self.fields.append(field)

        # 31 image.POLEGOTOJAIL
        field = Parking(31, x, y, image.POLEGOTOJAIL)
        x += field.image.get_width()
        self.fields.append(field)

        # 32

        # 33

        # 34

        # 35

        # 36

        # 37

        # 38

        # 39

        # 40

        # 41



    def draw(self, screen):
        for field in self.fields:
            field.draw(screen)
