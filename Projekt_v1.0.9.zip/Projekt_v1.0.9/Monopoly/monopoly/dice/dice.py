import random
from ..image import *


class Dice:
    def __init__(self):
        self.turn_value = 0
        self.dice1 = 0
        self.dice2 = 0
        self.doublet = False

    def dice_roll(self):
        value = random.randint(1, 6)
        return value

    def double_roll(self):
        self.dice1 = self.dice_roll()
        self.dice2 = self.dice_roll()
        if self.dice1 == self.dice2:
            self.doublet = True
        self.turn_value = self.dice1 + self.dice2

    def get_turn_value(self):
        return self.turn_value

    def draw(self, screen):
        dice_images = (image.DICE1, image.DICE2, image.DICE3, image.DICE4, image.DICE5, image.DICE6)
        for x in range(1, 7):
            if self.dice1 == x:
                img1 = dice_images[x - 1]
            if self.dice2 == x:
                img2 = dice_images[x - 1]

        if self.dice1 > 0 and self.dice2 > 0:
            screen.blit(img1, (350, 300))
            screen.blit(img2, (550, 300))
