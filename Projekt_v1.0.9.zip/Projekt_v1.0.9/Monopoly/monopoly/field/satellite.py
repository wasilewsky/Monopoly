import pygame
from .field import Field


class Satellite(Field):
    """
    representation of the 'satellite' field
    """
    def __init__(self, index, pos_x, pos_y, image, att, screen):
        super().__init__(index, 'satellite', pos_x, pos_y, image)
        self.hitbox = pygame.Rect(self.pos_x, self.pos_y, self.image.get_width(), self.image.get_height())
        self.owner = None
        self.att = att
        self.screen = screen
        self.clicked = False
        self.mortgage = False

    def field_clicked(self):
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            if pygame.mouse.get_pressed()[0]:
                if not self.clicked:
                    self.clicked = True
                else:
                    self.clicked = False
                pygame.time.delay(200)
                return self

    def field_mouse_on(self):
        # TODO napis
        if self.hitbox.collidepoint(pygame.mouse.get_pos()):
            # ----------TŁO KARTY-----------------------
            pygame.draw.rect(self.screen, 'WHITE', (250, 550, 176, 286), 0, 10, -10, -10, -10,
                             -10)  # tło karty
            pygame.draw.rect(self.screen, (0, 0, 0), (253, 553, 170, 280), 2, 10, -10, -10, -10,
                             -10)  # ramka
            pygame.draw.rect(self.screen, (0, 0, 0), (256, 556, 164, 54), 2, 10, -10, -10, -10,
                             -10)  # ramka koloru
            text5 = pygame.font.Font.render(pygame.font.SysFont(None, 30), f"{self.att[14]}", True, (0, 0, 0))
            self.screen.blit(text5, (263, 574))
            # ------------------------------------------
            font = pygame.font.SysFont(None, 20)
            pos_x_left = 260
            pos_x_right = 385
            pos_y = 617

            for att in [2, 3, 4, 5]:
                if att == 2:
                    text_surface_left = font.render(f"Czynsz: ", True,
                                                    (0, 0, 0))
                    self.screen.blit(text_surface_left, (pos_x_left, pos_y))
                elif att == 3:
                    text_surface_left = font.render(f"Przy 2 stacjach: ", True,
                                                    (0, 0, 0))
                    self.screen.blit(text_surface_left, (pos_x_left, pos_y))
                elif att == 4:
                    text_surface_left = font.render(f"Przy 3 stacjach: ", True,
                                                    (0, 0, 0))
                    self.screen.blit(text_surface_left, (pos_x_left, pos_y))
                elif att == 5:
                    text_surface_left = font.render(f"Przy 4 stacjach: ", True,
                                                    (0, 0, 0))
                    self.screen.blit(text_surface_left, (pos_x_left, pos_y))

                text_surface_right = font.render(f"${self.att[att]}", True, (0, 0, 0))
                self.screen.blit(text_surface_right, (pos_x_right, pos_y))

                pos_y += 50

    def draw(self, screen):
        self.screen = screen
        screen.blit(self.image, (self.pos_x, self.pos_y))

        for color in self.standing_players:
            self._draw_player(color, screen)

        if self.owner is not None:
            self._draw_owner(screen)

        if self.mortgage:
            self._draw_mortgage(screen)

        self._draw_main_border(screen)

        if self.clicked:
            self._draw_border(screen)

    def _draw_border(self, screen):
        # up
        pygame.draw.rect(screen, 'BLACK', (self.pos_x, self.pos_y, self.image.get_width(), 5))
        # left
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x, self.pos_y, 5, self.image.get_height()))
        # down
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x, self.pos_y + self.image.get_height() - 5, self.image.get_width(), 5))
        # right
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x + self.image.get_width() - 5, self.pos_y, 5, self.image.get_height()))

    def _draw_owner(self, screen):
        color = None

        if self.owner.color == 'red':
            color = 'RED'
        if self.owner.color == 'blue':
            color = 'BLUE'
        if self.owner.color == 'green':
            color = 'GREEN'
        if self.owner.color == 'purple':
            color = 'PURPLE'

        if self.index == 6:
            pygame.draw.rect(screen, color, (self.pos_x + 1, self.pos_y + 117 - 15, 70, 15))
        if self.index == 16:
            pygame.draw.rect(screen, color, (self.pos_x, self.pos_y + 1, 15, 70))
        if self.index == 26:
            pygame.draw.rect(screen, color, (self.pos_x + 1, self.pos_y, 70, 15))
        if self.index == 36:
            pygame.draw.rect(screen, color, (self.pos_x + 117 - 15, self.pos_y + 1, 15, 70))

    def _draw_mortgage(self, screen):
        color = 'gray'

        if self.index == 6:
            pygame.draw.rect(screen, color, (self.pos_x, self.pos_y + 117 - 30, 70, 15))
        if self.index == 16:
            pygame.draw.rect(screen, color, (self.pos_x + 15, self.pos_y, 15, 70))
        if self.index == 26:
            pygame.draw.rect(screen, color, (self.pos_x, self.pos_y + 15, 70, 15))
        if self.index == 36:
            pygame.draw.rect(screen, color, (self.pos_x + 117 - 30, self.pos_y + 1, 15, 70))

    def _draw_player(self, player, screen):
        if self.index == 6:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

        if self.index == 16:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 30, self.pos_y + 18, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 50, self.pos_y + 18, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 30, self.pos_y + 38, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 50, self.pos_y + 38, 15, 15))

        if self.index == 26:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

        if self.index == 36:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 40, self.pos_y + 18, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 60, self.pos_y + 18, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 40, self.pos_y + 38, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 60, self.pos_y + 38, 15, 15))

    def player_on_field_action(self, player):
        satellite_counter = 0
        tax = 0
        index = (6, 16, 26, 36)
        if self.owner is not None and self.owner != player and not self.mortgage and not self.owner.bankrupt:
            for field in self.owner.board.fields:
                if field.index in index and field.owner == self.owner and not field.mortgage:
                    satellite_counter += 1

            if satellite_counter == 1:
                tax = 25
            if satellite_counter == 2:
                tax = 50
            if satellite_counter == 3:
                tax = 100
            if satellite_counter == 4:
                tax = 200

            if player.money < tax:
                player.bankrupt = True
                return f'gracz {player.color} bankrutuje'
            else:
                player.money -= tax
                self.owner.money += tax
                return f'{player.color} płaci graczowi {self.owner.color} ${tax}'

