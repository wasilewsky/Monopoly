import pygame


class Field:
    def __init__(self, index, name, pos_x, pos_y, image):
        """
        constructor
        """
        self.index = index
        self.name = name
        self.pos_x = pos_x
        self.pos_y = pos_y
        self.image = image
        self.standing_players = []
        self.screen = None

    def field_clicked(self):
        raise Exception("field_clicked() not implemented")

    def field_mouse_on(self):
        raise Exception("field_mouse_on() not implemented")

    def player_on_field_action(self, player):
        raise Exception("player_on_field_action() not implemented")

    def draw(self, screen):
        self.screen = screen
        screen.blit(self.image, (self.pos_x, self.pos_y))

        for color in self.standing_players:
            self._draw_player(color, screen)

        self._draw_main_border(screen)

    def add_player(self, player):
        if player not in self.standing_players:
            self.standing_players.append(player)

    def remove_player(self, player):
        if player in self.standing_players:
            self.standing_players.remove(player)

    def _draw_player(self, player, screen):
        if player.color == 'red':
            if not player.bankrupt:
                pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
        if player.color == 'blue':
            if not player.bankrupt:
                pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
        if player.color == 'green':
            if not player.bankrupt:
                pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
        if player.color == 'purple':
            if not player.bankrupt:
                pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

    def _draw_main_border(self, screen):
        # up
        pygame.draw.rect(screen, 'BLACK', (self.pos_x, self.pos_y, self.image.get_width(), 1))
        # left
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x, self.pos_y, 1, self.image.get_height()))
        # down
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x, self.pos_y + self.image.get_height() - 1, self.image.get_width(), 1))
        # right
        pygame.draw.rect(screen, 'BLACK',
                         (self.pos_x + self.image.get_width() - 1, self.pos_y, 1, self.image.get_height()))
