import pygame
from .field import Field


class Tax(Field):
    """
    representation of the 'tax' field
    """
    def __init__(self, index, pos_x, pos_y, image, tax_amount=100):
        super().__init__(index, 'tax', pos_x, pos_y, image)
        self.tax_amount = tax_amount
        self.money_bank = 0

    def field_clicked(self):
        pass

    def field_mouse_on(self):
        pass

    def _draw_player(self, player, screen):
        if self.index == 5:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 18, self.pos_y + 40, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 38, self.pos_y + 40, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 18, self.pos_y + 60, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 38, self.pos_y + 60, 15, 15))

        if self.index == 39:
            if player.color == 'red':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#ff0000', (self.pos_x + 40, self.pos_y + 18, 15, 15))
            if player.color == 'blue':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#0000ff', (self.pos_x + 60, self.pos_y + 18, 15, 15))
            if player.color == 'green':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#00ff00', (self.pos_x + 40, self.pos_y + 38, 15, 15))
            if player.color == 'purple':
                if not player.bankrupt:
                    pygame.draw.rect(screen, '#cc00ff', (self.pos_x + 60, self.pos_y + 38, 15, 15))

    def player_on_field_action(self, player):
        if player.money < self.tax_amount:
            player.bankrupt = True
            return f'gracz {player.color} bankrutuje'
        else:
            player.money -= self.tax_amount
            self.money_bank += self.tax_amount
            return f'gracz {player.color} płaci podatek (-${self.tax_amount})'
