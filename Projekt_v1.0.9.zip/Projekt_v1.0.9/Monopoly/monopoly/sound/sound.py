import pygame, os

pygame.mixer.init()

path = os.path.join(os.pardir, 'Monopoly/sound')

BUTTON_SOUND1 = pygame.mixer.Sound(os.path.join(path, 'click_sound.wav'))
HITBOX_SOUND1 = pygame.mixer.Sound(os.path.join(path, 'choose_sound.wav'))

BACKGROUND_SOUND1 = pygame.mixer.Sound(os.path.join(path, 'background1.wav'))
BACKGROUND_SOUND2 = pygame.mixer.Sound(os.path.join(path, 'background2.mp3'))

HITBOX_SOUND1.set_volume(0.1)
BUTTON_SOUND1.set_volume(0.1)

BACKGROUND_SOUND1.set_volume(0.02)
BACKGROUND_SOUND2.set_volume(0.02)
