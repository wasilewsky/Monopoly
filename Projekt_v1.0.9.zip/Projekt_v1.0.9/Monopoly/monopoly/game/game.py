from ..board import *
from ..player import *
from ..message import *
from ..button import *
from ..image import *
from ..info_table import *
from ..dice import *


class Game:
    def __init__(self, screen, selected_color):
        self.board = Board()
        self.screen = screen
        self.selected_color = selected_color
        self.message = Message()
        self.rzut_button = Button(1000, 750, image.RZUT_BTN, True)
        self.kup_button = Button(1220, 750, image.KUPPOLE_BTN, True)
        self.kupDom_button = Button(1440, 750, image.KUPDOM_BTN, True)
        self.sprzedajDom_button = Button(1660, 750, image.SPRZEDAJDOM_BTN, True)
        self.zastaw_button = Button(1000, 870, image.ZASTAW_BTN, True)
        self.wykup_button = Button(1220, 870, image.WYKUP_BTN, True)
        self.handel_button = Button(1440, 870, image.HANDEL_BTN, True)
        self.dalej_button = Button(1660, 870, image.DALEJ_BTN, True)
        self.dice_rolled = False
        self.players = []
        self.info_table = InfoTable(screen, self.players)
        self.dice = Dice()
        self.round_counter = 0
        self.game_over = False
        self.end_message = '@ KONIEC GRY'


        self._make_players()
        self.current_player_index = 3
        self.switch_player()


    def draw(self):
        # update money in chest field bank
        chest1 = self.board.get_field(3)
        chest2 = self.board.get_field(18)
        chest3 = self.board.get_field(34)
        tax1 = self.board.get_field(5)
        tax2 = self.board.get_field(39)

        if chest1.bank == -1 or chest2.bank == -1 or chest3.bank == -1:
            tax1.money_bank = 0
            tax2.money_bank = 0
        chest1.bank = tax1.money_bank + tax2.money_bank
        chest2.bank = tax1.money_bank + tax2.money_bank
        chest3.bank = tax1.money_bank + tax2.money_bank
        # --------

        self.board.draw(self.screen)
        self.message.show_message(self.screen)
        self.info_table.draw()

        self.rzut_button.draw(self.screen)
        self.kup_button.draw(self.screen)
        self.kupDom_button.draw(self.screen)
        self.sprzedajDom_button.draw(self.screen)

        self.zastaw_button.draw(self.screen)
        self.wykup_button.draw(self.screen)
        self.handel_button.draw(self.screen)
        self.dalej_button.draw(self.screen)

        self.dice.draw(self.screen)

        print(self.round_counter)
        # -----------------wszystko rysujemy na początku pętli



        # game over
        if self.game_over:
            self.message.add_message(self.end_message)
            self.message.add_message('WYNIKI:')
            if self.players[0].bankrupt:
                self.message.add_message(f'{self.players[0].color}: BANKRUT')
                self.message.add_message('warotść nieruchomości: 0')
            else:
                field_money = 0
                field_houses= 0
                for field in self.board.fields:
                    if hasattr(field, 'owner'):
                        if field.owner == self.players[0]:
                            if hasattr(field, 'home_counter'):
                                field_houses += field.home_counter * field.att[9]
                                if field.home_counter > 4:
                                    field_houses += (field.home_counter-4) * (field.att[10]-field.att[9])
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1]/2)
                            else:
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1]/2)
                self.message.add_message(f'{self.players[0].color}: kasa: ${self.players[0].money}')
                self.message.add_message(f'warotść nieruchomości: ${field_money}')


            if self.players[1].bankrupt:
                self.message.add_message(f'{self.players[1].color}: BANKRUT')
                self.message.add_message('warotść nieruchomości: 0')
            else:
                field_money = 0
                field_houses = 0
                for field in self.board.fields:
                    if hasattr(field, 'owner'):
                        if field.owner == self.players[1]:
                            if hasattr(field, 'home_counter'):
                                field_houses += field.home_counter * field.att[9]
                                if field.home_counter > 4:
                                    field_houses += (field.home_counter - 4) * (field.att[10] - field.att[9])
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1] / 2)
                            else:
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1] / 2)
                self.message.add_message(f'{self.players[1].color}: kasa: ${self.players[1].money}')
                self.message.add_message(f'warotść nieruchomości: ${field_money}')

            if self.players[2].bankrupt:
                self.message.add_message(f'{self.players[2].color}: BANKRUT')
                self.message.add_message('warotść nieruchomości: 0')
            else:
                field_money = 0
                field_houses = 0
                for field in self.board.fields:
                    if hasattr(field, 'owner'):
                        if field.owner == self.players[2]:
                            if hasattr(field, 'home_counter'):
                                field_houses += field.home_counter * field.att[9]
                                if field.home_counter > 4:
                                    field_houses += (field.home_counter - 4) * (field.att[10] - field.att[9])
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1] / 2)
                            else:
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1] / 2)
                self.message.add_message(f'{self.players[2].color}: kasa: ${self.players[2].money}')
                self.message.add_message(f'warotść nieruchomości: ${field_money}')

            if self.players[3].bankrupt:
                self.message.add_message(f'{self.players[3].color}: BANKRUT')
                self.message.add_message('warotść nieruchomości: 0')
            else:
                field_money = 0
                field_houses = 0
                for field in self.board.fields:
                    if hasattr(field, 'owner'):
                        if field.owner == self.players[3]:
                            if hasattr(field, 'home_counter'):
                                field_houses += field.home_counter * field.att[9]
                                if field.home_counter > 4:
                                    field_houses += (field.home_counter - 4) * (field.att[10] - field.att[9])
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1] / 2)
                            else:
                                if not field.mortgage:
                                    field_money += field.att[1]
                                else:
                                    field_money += int(field.att[1] / 2)
                self.message.add_message(f'{self.players[3].color}: kasa: ${self.players[3].money}')
                self.message.add_message(f'warotść nieruchomości: ${field_money}')

        bankrupt_count = 0
        for player in self.players:
            if player.bankrupt:
                bankrupt_count += 1
        if bankrupt_count == 2 and not self.game_over:
            self.game_over = True
            self.end_message = '@ KONIEC GRY - zostało 2 graczy'
            return



        if self.current_player_index != 0 and not self.game_over:
            self.dice_rolled = False
            self.round_counter += 1
            if self.players[self.current_player_index].player_action():
                self.switch_player()

        if self.dalej_button.click():
            self.dalej_button.set_visible(False)
            self.kup_button.set_visible(False)
            self.kupDom_button.set_visible(False)
            self.sprzedajDom_button.set_visible(False)
            self.zastaw_button.set_visible(False)
            self.wykup_button.set_visible(False)
            self.handel_button.set_visible(False)
            self.dalej_button.set_visible(False)

            if not self.players[self.current_player_index].bankrupt:
                self.round_counter += 1
            self.switch_player()
            return

        if self.rzut_button.click():
            self.dice_rolled = True
            self.rzut_button.set_visible(False)
            self.dalej_button.set_visible(True)

            self.dice.double_roll()
            self.message.add_message(f"wyrzuciłeś {self.dice.get_turn_value()}")
            self.message.show_message(self.screen)
            self.dice.draw(self.screen)
            pygame.time.delay(1000)
            pygame.display.update()

            # self.players[self.current_player_index].move(self.dice.get_turn_value())
            self.players[self.current_player_index].move(1)
            self.board.draw(self.screen)
            self.dice.draw(self.screen)
            pygame.display.update()
            return

        if self.kup_button.click():
            actual_field = self.board.get_field(self.players[0].position)
            actual_field.owner = self.players[0]
            self.players[0].money -= actual_field.att[1]
            self.message.add_message(f'kupiłeś pole {actual_field.att[14]} za {actual_field.att[1]}')
            pygame.time.delay(200)
            return

        if self.zastaw_button.click():
            self.zastaw_button.set_visible(False)
            clicked_field = self.board.get_clicked_field()
            clicked_field.mortgage = True
            clicked_field.clicked = False
            clicked_field.owner.money += int(clicked_field.att[1]/2)
            self.message.add_message(f'zastawiłeś pole {clicked_field.att[14]} (+ ${int(clicked_field.att[1]/2)})')
            pygame.time.delay(200)
            return

        if self.wykup_button.click():
            self.wykup_button.set_visible(False)
            clicked_field = self.board.get_clicked_field()
            clicked_field.mortgage = False
            clicked_field.clicked = False
            clicked_field.owner.money -= int(clicked_field.att[1]*0.6)
            self.message.add_message(f'wykupiłeś pole {clicked_field.att[14]} (- ${int(clicked_field.att[1]*0.6)})')
            pygame.time.delay(200)
            return

        if self.kupDom_button.click():
            self.kupDom_button.set_visible(False)
            clicked_field = self.board.get_clicked_field()
            clicked_field.clicked = False
            if clicked_field.home_counter < 4:
                clicked_field.owner.money -= int(clicked_field.att[9])
                clicked_field.home_counter += 1
                self.message.add_message(f'kupiłeś dom (- ${int(clicked_field.att[9])})')
            elif 3 < clicked_field.home_counter < 8:
                clicked_field.owner.money -= int(clicked_field.att[10])
                clicked_field.home_counter += 1
                self.message.add_message(f'kupiłeś hotel (- ${int(clicked_field.att[10])})')
            pygame.time.delay(200)
            return

        if self.sprzedajDom_button.click():
            self.sprzedajDom_button.set_visible(False)
            clicked_field = self.board.get_clicked_field()
            clicked_field.clicked = False
            if clicked_field.home_counter < 5:
                clicked_field.owner.money += int(clicked_field.att[9]/2)
                clicked_field.home_counter -= 1
                self.message.add_message(f'sprzedałeś dom (- ${int(clicked_field.att[9] / 2)})')
            elif 4 < clicked_field.home_counter < 9:
                clicked_field.owner.money += int(clicked_field.att[10]/2)
                clicked_field.home_counter -= 1
                self.message.add_message(f'sprzedałeś hotel (- ${int(clicked_field.att[10]/2)})')
            pygame.time.delay(200)
            return

        # ----------------------- warunki:

        if self.current_player_index == 0 and not self.dice_rolled:
            if self.players[0].bankrupt:
                self.rzut_button.set_visible(False)
                return

            if self.players[0].prison_counter > 0:
                self.message.add_message(
                    f'@ odsiadujesz w więzieniu (zostało: {self.players[0].prison_counter})')
                self.message.show_message(self.screen)
                pygame.display.update()
                pygame.time.delay(1000)
                self.players[0].prison_counter -= 1
                self.switch_player()
                return
            self.rzut_button.set_visible(True)
            self.kup_button.set_visible(False)
            self.kupDom_button.set_visible(False)
            self.sprzedajDom_button.set_visible(False)
            self.zastaw_button.set_visible(False)
            self.wykup_button.set_visible(False)
            self.handel_button.set_visible(False)
            self.dalej_button.set_visible(False)
            return

        if self.current_player_index == 0 and self.dice_rolled and not self.players[0].bankrupt:
            # tutaj sprawdzanie co można robic na polu i właczanie przycisków podczas tury gracza
            # pole do kupienia
            actual_field = self.board.get_field(self.players[0].position)
            if hasattr(actual_field, 'owner'):
                if actual_field.owner is None and self.players[0].money >= actual_field.att[1]:
                    self.kup_button.set_visible(True)
                else:
                    self.kup_button.set_visible(False)

            # wyswietlanie przycisku zastaw/wykup
            self.zastaw_button.set_visible(False)
            self.wykup_button.set_visible(False)
            for field in self.board.fields:
                if hasattr(field, 'clicked') and hasattr(field, 'mortgage') and not hasattr(field, 'home_counter'):
                    if field.clicked and field.owner == self.players[0] and not field.mortgage:
                        self.zastaw_button.set_visible(True)
                    elif field.clicked and field.owner == self.players[0] and field.mortgage:
                        if field.owner.money > int(field.att[1]*0.6):
                            self.wykup_button.set_visible(True)
                elif hasattr(field, 'clicked') and hasattr(field, 'mortgage') and hasattr(field, 'home_counter'):
                    all_color_f = self.board.get_all_color_fields(field.name)
                    have_home = False
                    for x in all_color_f:
                        if x.home_counter > 0:
                            have_home = True
                    if field.clicked and field.owner == self.players[0] and not field.mortgage and not have_home:
                        self.zastaw_button.set_visible(True)
                    elif field.clicked and field.owner == self.players[0] and field.mortgage:
                        if field.owner.money > int(field.att[1]*0.6):
                            self.wykup_button.set_visible(True)

            # kupowanie domu/hotelu
            self.kupDom_button.set_visible(False)
            for field in self.board.fields:
                if hasattr(field, 'clicked') and hasattr(field, 'mortgage') and hasattr(field, 'home_counter'):
                    if field.clicked:
                        all_color_f = self.board.get_all_color_fields(field.name)
                        have_monopol = True
                        home_count = field.home_counter
                        for x in all_color_f:
                            if x.owner != self.players[0] or x.mortgage:
                                have_monopol = False
                        if have_monopol and home_count < 4:
                            if self.players[0].money >= actual_field.att[9]:
                                self.kupDom_button.set_visible(True)
                        elif have_monopol and 3 < home_count < 8:
                            if self.players[0].money >= actual_field.att[10]:
                                self.kupDom_button.set_visible(True)

            # sprzedawanie domu/hotelu
            self.sprzedajDom_button.set_visible(False)
            for field in self.board.fields:
                if hasattr(field, 'clicked') and hasattr(field, 'mortgage') and hasattr(field, 'home_counter'):
                    if field.clicked and field.owner == self.players[0]:
                        home_count = field.home_counter
                        if 0 < home_count:
                            self.sprzedajDom_button.set_visible(True)




    def _make_players(self):
        main_player = MainPlayer(self.selected_color, self)
        self.players.append(main_player)

        colors = ['red', 'blue', 'green', 'purple']
        colors.remove(self.selected_color)

        for color in colors:
            ai_player = AiPlayer(color, self)
            self.players.append(ai_player)

    def switch_player(self):
        if self.round_counter > 16:  # 160 -> 4 players * 40 rounds
            # self.message.add_message('@ koniec gry (więcej jak 40 rund)')
            self.end_message = '@ koniec gry (więcej jak 40 rund)'
            self.game_over = True
            return
        self.current_player_index = (self.current_player_index + 1) % len(self.players)
        if self.current_player_index == 0 and self.players[0].prison_counter == 0 and not self.players[0].bankrupt:
            self.message.add_message('@ twoja kolej:')
        elif self.current_player_index == 0 and self.players[0].bankrupt:
            self.current_player_index = (self.current_player_index + 1) % len(self.players)
