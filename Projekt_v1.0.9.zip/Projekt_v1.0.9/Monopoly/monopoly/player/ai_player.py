import pygame.time
from .player import Player


class AiPlayer(Player):
    def __init__(self, color, game):
        super().__init__(color, game)
        self.dice = game.dice
        self.game_over = game.game_over

    def player_action(self):
        if self.bankrupt:
            return True
        if self.is_in_prison:
            self.prison_counter -= 1
            return True
        if self.game_over:
            return True

        self.message.add_message(f"@ tura gracza {self.color}")
        self.message.show_message(self.screen)
        pygame.display.update()

        self.dice.double_roll()

        pygame.time.delay(1000)
        self.message.add_message(f"gracz {self.color} wyrzucił {self.dice.get_turn_value()}")
        self.message.show_message(self.screen)
        self.dice.draw(self.screen)
        pygame.display.update()

        pygame.time.delay(1000)
        #self.move(self.dice.get_turn_value())
        self.move(4)
        pygame.display.update()
        return True

